<?php
# -- Developer @ImDevAbolfazl -- #
# -- لیک شده توسط BIKstl -- #


//========================== // token // ==============================
define('API_KEY',"TOKEN");// توکن
//========================== // config // ==============================
$sudo           = "admin";
$admin          = ["admin","00","11"];
$usernamebot    = "TestnameBIKSeenbot";// آیدی ربات
$botid          = "1326590938";// آیدی عددی ربات
$channel        = "TestnameBIKSeen";// آیدی کانال
$channelidtag   = "-12345";// آیدی عددی کانال
$channelorder   = "sdrfkaerfaekf";// آیدی کانال سفارشات
$channelorderid = "-12345";// آیدی عددی کانال سفارشات
$channelname    = "پاندا سین";// اسم کانال
$botname        = "پاندا سین";// اسم ربات
$botnameEN      = "TestnameBIK Seen";// اسم انگلیسی ربات
$web            = "https://me.irateam.ir/seen";// محل قرارگیری سورس
$webapi         = "https://cleverseen.ir/api/api.php";// آدرس وبسرویس سین و لایک
$solowebapi     = "https://soloseen.ir/api";// آدرس وبسرویس کلور
$usernamesup    = "@TestnameBIKSeenSup7";// آیدی پشتیبانی
$botsendaccount = "TestnameBIKSeenBot";// آیدی ربات ارسال اکانت
$cardinfo       = "سلام کاربرد عزیز جهت پرداخت به صورت کارت به کارت به پیو پشتیبانی مراجعه نمایید✅ \n 👨‍💻 @TestnameBIKSeenSup7"; // اطلاعات کارت برای خرید آفلاین
$baner          = "https://t.me/TestnameBIKSeen/8";// لینک عکس بنر زیرمجموعه
$adminapi       = "12345";// آیدی عددی ادمین وبسرویس
$apisolo        = "12345";// کلید وبسرویس سولو
$apikey         = "12345";// کلید وبسرویس کلور ( سین و لایک )
$apisms         = "12345";// توکن وبسرویس اس ام اس ( @smsotp_bot )
$webserviceid   = "@TestnameBIKSeenApiBot";

//========================== // database // ==============================
$connect = new mysqli('localhost','DbUser','DbPass','DbName'); // اطلاعات دیتابیس 
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
$settingmerch = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
?>