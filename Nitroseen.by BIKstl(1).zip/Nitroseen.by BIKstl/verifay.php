<?php
error_reporting(0);

foreach(scandir("data") as $f){
unlink("data/$f/ok.txt");
}
?>