<?php
include '../../config.php';
if(isset($_GET['a']) and isset($_GET['i'])){
$a = $_GET['a'];
$i = $_GET['i'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array('order_id' => '1','amount' => $a.'0','callback' => "$web/pay/idpay/back.php?i=$i&a=$a",)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"X-API-KEY: idpaykey",));
$result = json_decode(curl_exec($ch));
curl_close($ch);
header("Location: $result->link");
}
?>