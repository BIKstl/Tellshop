<?php

include '../../botedmatike3iotfaka.php';
include '../../config.php';
$id = $_POST['id'];
if(isset($_GET['a']) and isset($_GET['i'])){
$user = $_GET['i'];
$amount = $_GET['a'];
$cbvarizi = "@adskfkadgk";// channel pay
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array('id' => $id,  'order_id' => '1',)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"X-API-KEY: 4b4d3c67-0e76-4bbc-83f5-fcf58aa5fc3c",));
$result = json_decode(curl_exec($ch));
curl_close($ch);

if($result->status == 100){

$userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$pluscoin = $userdata['coin']  +  $amount;

bot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"✅ #پرداخت_موفق 
⬆️ با تشکر از خرید شما , موجودی حساب شما افزایش یافت

💰 موجودی جدید شما : $pluscoin تومان
☑️ مبلغ پرداخت شده : $amount تومان
",
	'reply_markup'=>$home
            ]);
$connect->query("UPDATE `user` SET `coin` = '$pluscoin' WHERE `id` = '$user' LIMIT 1");	
$connect->query("INSERT INTO `buy` (`id` , `amount` , `time`) VALUES ('$user' , '$amount' , '$time')");
if($userdata['inviter'] != '0'){
$inviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '{$userdata['inviter']}' LIMIT 1"));
$porsant = round(($amount * $_porsant) / 100);
$pluscoin = $inviter['coin']  +  $porsant;
bot('sendmessage',[
	'chat_id'=>$userdata['inviter'],
	'text'=>"✅ تبریک ! زیر مجموعه شما از ربات خرید کرده و 5 درصد از موجودی خریداری شده به عنوان هدیه به شما تعلق گرفت
	
💰 موجودی جدید شما : $pluscoin تومان
🛍 موجودی خریداری شده : $amount تومان
🎁 مقدار هدیه : $porsant تومان
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE `user` SET `coin` = '$pluscoin' WHERE `id` = '{$userdata['inviter']}' LIMIT 1");
}
bot('sendmessage',[
	'chat_id'=>$cbvarizi,
	'text'=>"✅ #پرداخت موفق
	
💳 مبلغ خرید : $amount تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);

}}

?>
<html lang="en">
<head>
  <title>Panda Seen | پاندا سین</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://microseen.otpserver.net/view/res/css/style.css?v=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <br>
  <div class="alert alert-danger">
      <div class="card border-danger mb-12" >
          <div class="card-header bg-transparent border-danger text-danger">وبسرویس پاندا سین</div>
          <div class="card-body">
            <p class="card-text">خرید شما با موفقیت انجام شد و موجودی حساب شما افزایش یافت</br> آدرس ربات : PandaSeenApiBot@</p>
          </div>
      </div>
  </div> 
</div>
</body>
</html>