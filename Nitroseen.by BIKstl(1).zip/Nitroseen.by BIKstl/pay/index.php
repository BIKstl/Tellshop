<!DOCTYPE HTML>
<?php 
# -- @DevAbolfazl -- @IRA_Team -- #
//==================================================
include '../botedmatike3iotfaka.php';
include '../config.php';
//====================//  Get  //==============================
$user = $_GET['id'];
$amount = $_GET['amount'];
$name = bot('getChatMember',['chat_id'=>$user,'user_id'=>$user])->result->user->first_name;
//==================================================
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
  'order_id' => '1',
  'amount' => $amount.'0',
  'callback' => "$web/pay/back.php?id=$user&amount=$amount",
)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  'Content-Type: application/json',
  "X-API-KEY: $MerchantID",
));
$result = json_decode(curl_exec($ch));
curl_close($ch);
# -- @DevAbolfazl -- @IRA_Team -- #
//==============================================================
# -- @DevAbolfazl -- @IRA_Team -- #
?>
<html>
	<head>
		<title>ربات پاندا سین</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="ربات پاندا سین | صفحه افزایش موجودی ربات پاندا سین">
        <meta name="keywords" content="ربات پاندا سین">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات پاندا سین</h1>
						<p>صفحه افزایش موجودیِ حساب</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>افزایش موجودی برای شناسه <?php echo "'$user'";?></h2>
										</header>
										<h3><?php echo "$name عزیز";?></h3>
										<p>برای افزایش موجودی حساب خود  به مبلغ <?php echo $amount;?> تومان , کافیست از دکمه زیر استفاده کنید تا به صحفه پرداخت مطمئن منتقل شوید و پس از خرید موجودی حساب شما به صورت خودکار افزایش پیدا خواهد کرد</p>
										<ul class="actions">
											<li><a href="<?php echo $result->link;?>" class="button">پرداخت <?php echo $amount;?> تومان</a></li>
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
