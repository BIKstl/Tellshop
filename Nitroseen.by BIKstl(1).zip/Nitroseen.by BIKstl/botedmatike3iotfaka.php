<?php
/*
@BIKstl
*/

ob_start();
include 'config.php';
include('lib/jdf.php');
//========================== // bot // ==============================
function bot($method,$datas=[]){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,'https://api.telegram.org/bot'.API_KEY.'/'.$method );
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    return json_decode(curl_exec($ch));
    }
//========================== // update // ==============================
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$message = $update->message;
$message_id = $message->message_id;
$text = convert($message->text);
$chat_id = $message->chat->id;
$tc = $message->chat->type;
$first_name = $message->from->first_name;
$from_id = $message->from->id;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$from_id' LIMIT 1"));
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$from_id' LIMIT 1");
}
if(isset($update->callback_query)){
$callback_query = $update->callback_query;
$callback_query_id = $callback_query->id;
$data = $callback_query->data;
$fromid = $callback_query->from->id;
$messageid = $callback_query->message->message_id;
$chatid = $callback_query->message->chat->id;
// databs
$from_id = $callback_query->from->id;
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$fromid' LIMIT 1"));
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
$block = mysqli_query($connect,"SELECT * FROM `block` WHERE `id` = '$fromid' LIMIT 1");
$text = $callback_query->data;
}
if(isset($update->channel_post)){
$channel_post = $update->channel_post;
$channel_post_message_id = $channel_post->message_id;
$channel_post_chat_id = $channel_post->chat->id;
$channel_post_chat_username = $channel_post->chat->username;
$channel_post_chat_type = $channel_post->chat->type;
// databse
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `channel` WHERE `channel` = '$channel_post_chat_id' LIMIT 1"));
}
date_default_timezone_set('Asia/Tehran');
$time11 = date('H:i:s');
$timeji = str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],range(0,9),$time11);
$dateji = gregorian_to_jalali(date('Y'), date('m'), date('d'), '/'); 
/*
@Sourrce_Kade
*/
//==============================// function //=======================================
function curl($url){
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    return json_decode(curl_exec($ch));
    }
function convert($string) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١','٠'];
    $num = range(0, 9);
    $convertedPersianNums = str_replace($persian, $num, $string);
    $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);
    return $englishNumbersOnly;
}
$settingmerch = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
function pay($Amount){
global $from_id;
global $settingmerch;
global $web;
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl',['encoding' => 'UTF-8']);
$result = $client->PaymentRequest([
'MerchantID' => "{$settingmerch['MerchantID']}", // مرچند کد زرین پال
'Amount' => $Amount,
'Description' => "ربات $botname | سکه $coin عدد | قیمت $Amount تومان | کاربر $from_id",
'Email' => 'mail', // ایمیل 
'Mobile' => 'mob', // موبایل
'CallbackURL' => "$web/back.php?id=".$from_id."&amount=".$Amount]);//ادرس سایت
if($result->Status == 100){
return "https://www.zarinpal.com/pg/StartPay/".$result->Authority."/ZarinGate";
}
}

//==============================// keybord and Text //=======================================
$home = json_encode([
        'keyboard'=>[
		[['text'=>'❤️ افزایش لایک'],['text'=>'👁 افزایش بازدید']],
		[['text'=>'🤖 بازدید کانال'],['text'=>'👍 ری‌اکشن'],['text'=>'👤 حساب من']],
		[['text'=>'💸 انتقال سکه'],['text'=>'➕ افزایش موجودی']],
		[['text'=>'🆘 پشتیبانی و قوانین']],
		],
          'resize_keyboard'=>true,
		  'input_field_placeholder' => "$botname 🏡"
       		]);
$homeen = json_encode([
        'keyboard'=>[
		[['text'=>'❤️ Like'],['text'=>'👁 View']],
		[['text'=>'🤖 Auto-view'],['text'=>'🔎 Tracking'],['text'=>'👤 My account']],
		[['text'=>'💸 Coin transfer'],['text'=>'➕ Buy coins']],
		[['text'=>'🆘 Support and rules']],
		],
          'resize_keyboard'=>true,
		  'input_field_placeholder' => "$botnameEN 🏡"
       		]);
$changelan = json_encode([
        'keyboard'=>[
		[['text'=>'🏴󠁧󠁢󠁥󠁮󠁧󠁿 English'],['text'=>'🇮🇷 فارسی']],
		],
          'resize_keyboard'=>true,
		  'input_field_placeholder' => "$botnameEN 🏡"
       		]);
$vieworder = json_encode([
        'keyboard'=>[
		[['text'=>'👁 بازدید همزمان'],['text'=>'👁 بازدید تکی']],
		[['text'=>'انصراف']],
		],
          'resize_keyboard'=>true,
		  'input_field_placeholder' => "$botname 🏡"
       		]);
$back = json_encode([
        'keyboard'=>[
		[['text'=>'انصراف']],
		],
         'resize_keyboard'=>true,
       		]);
$backen = json_encode([
        'keyboard'=>[
		[['text'=>'Cancel']],
		],
         'resize_keyboard'=>true,
       		]);
$speed = json_encode([
        'keyboard'=>[
		[['text'=>'حداکثر سرعت'],['text'=>'تنظیم سرعت']],
		[['text'=>'سریع'],['text'=>'متوسط'],['text'=>'آهسته']],
		[['text'=>'انصراف']],
		],
         'resize_keyboard'=>true,
       		]);
$speeden = json_encode([
        'keyboard'=>[
		[['text'=>'Maximum speed'],['text'=>'Speed adjustment']],
		[['text'=>'Fast'],['text'=>'medium'],['text'=>'Slow']],
		[['text'=>'Cancel']],
		],
         'resize_keyboard'=>true,
       		]);
$speedlike = json_encode([
        'keyboard'=>[
		[['text'=>'حداکثر سرعت']],
		[['text'=>'هر 2 دقیقه 1 لایک'],['text'=>'هر 5 دقیقه 1 لایک']],
		[['text'=>'هر 15 دقیقه 1 لایک'],['text'=>'هر 30 دقیقه 1 لایک']],
		[['text'=>'انصراف']],
		],
         'resize_keyboard'=>true,
       		]);			
$speedlikeen = json_encode([
        'keyboard'=>[
		[['text'=>'Maximum speed']],
		[['text'=>'1 like every 2 minutes'],['text'=>'1 like every 5 minutes']],
		[['text'=>'1 like every 15 minutes'],['text'=>'1 like every 30 minutes']],
		[['text'=>'Cancel']],
		],
         'resize_keyboard'=>true,
       		]);		
$start = "سلام، به $botname خوش آمدید ✋

با $botname همراه شماییم تا به راحتی بازدید، لایک و رای پستهای تلگرامی شما را افزایش دهیم.
تغییر زبان: /language

برای ادامه کار یک بخش را انتخاب کنید:";	
$starten = "Hi, welcome to $botname ✋

With $botname it's just a few taps to increase number of views, likes and votes of your Telegram posts.
Change language: /language

To continue choose an item:";	
$gift = "🎊 با تشکر از عضویت شما ، {$setting['gift']} تومان موجودی به صورت هدیه به حسابتان افزوده شد .";		
$giften = "🎊 Thanks for your membership ، {$setting['gift']} The balance was added to your account as a gift.";		
//===========================// block //===========================
if(strpos($text,"$channelidtag") !== false){
exit;
}
if (mysqli_num_rows($block) > 0) exit();
if (file_exists('bot') and !in_array($from_id, $admin))  
return bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍 ربات جهت بروزرسانی خاموش است ! لطفا پیام مجدد ارسال نکنید.",
]);
if($update->my_chat_member->new_chat_member->status == 'kicked' ){
$user = $update->my_chat_member->from->id;
bot('Sendmessage',[
'chat_id'=>$sudo,
'text'=>"🧐 ربات توسط این اصکل بلاک شد :
[$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
]);
}
//===========================// start //===========================

elseif(preg_match('/^(\/start) (.*)/',$text , $prameter) and $user['id'] != true){
	$connect->query("INSERT INTO `user` (`id` , `coin` , `inviter`) VALUES ('$from_id' , '{$setting['gift']}' , '$prameter[2]')");
    if (bot('getChatMember', ['chat_id' => "@$channel", 'user_id' => $from_id])->result->status != 'left') {
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$start,
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
    		]);
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$gift,
    		]);
$name = str_replace(['`','*','_','[',']','(',')'],null,$first_name);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$prameter[2]' LIMIT 1"));
$member = $user['member'] + 1;
$coin = $user['coin'] + $setting['member'];
bot('sendmessage',[
	'chat_id'=>$prameter[2],
	'text'=>"🌟 تبریک ! کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده
	
	⬆️ مبلغ {{$setting['member']}} تومان به موجودی شما اضافه شد 
☑️ در صورت خرید توسط کسانی که شما دعوت میکنید {{$setting['porsant']}} درصد نیز به شما هدیه تعلق میگیرد

👥 تعداد زیر مجموعه ها : $member
💰 موجودی حساب شما : $coin تومان",
	'parse_mode'=>'Markdown',
	  	]); 
	
$connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$prameter[2]' LIMIT 1");	
}else{
    $connect->query("UPDATE `user` SET `step` = '$prameter[2]' WHERE `id` = '$from_id' LIMIT 1");
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$start,
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
    		]);
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$gift,
    		]);
    bot('sendmessage', [
      'chat_id' => $chat_id,
      "text" => "☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
 ❗️ برای دریافت آموزش ها ،  اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید
     
 📣 @$channel
 
 👇 بعد از عضویت در کانال روی دکمه « ✅ تایید عضویت » بزنید 👇",
      'reply_to_message_id' => $message_id,
      'reply_markup' => json_encode([
        'inline_keyboard' => [
          [['text' => '✅ تایید عضویت', 'callback_data' => "join_ozvs"]],
        ]
      ])
    ]);
  }
}
elseif ($data == "join_ozvs" and $user['ozv'] == 0) {
   $userdatainv = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$chatid' LIMIT 1"));
   $prameter = $userdatainv['step'];
   $connect->query("INSERT INTO `user` (`id` , `coin` , `inviter`) VALUES ('$fromid' , '{$setting['gift']}' , '$prameter')");
  if (bot('getChatMember', ['chat_id' => "@$channel", 'user_id' => $fromid])->result->status != 'left') {
    bot('sendmessage', [
      'chat_id' => $chatid,
      'text' => "☑️ عضویت شما در کانال تایید شد
$start",
      'reply_to_message_id' => $messageid,
      'reply_markup' => $home
    ]);
	
	
	
	$userdatainv = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `user` WHERE `id` = '$chatid' LIMIT 1"));
    $prameter = $userdatainv['step'];
	
	
$name = str_replace(['`','*','_','[',']','(',')'],null,$first_name);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$prameter' LIMIT 1"));
$member = $user['member'] + 1;
$coin = $user['coin'] + $setting['member'];
bot('sendmessage',[
	'chat_id'=>$prameter,
	'text'=>"🌟 تبریک ! کاربر [$fromid](tg://user?id=$fromid) با استفاده از لینک دعوت شما وارد ربات شده
	
⬆️ مبلغ {$setting['member']} تومان به موجودی شما اضافه شد 
☑️ در صورت خرید توسط کسانی که شما دعوت میکنید {$setting['porsant']} درصد نیز به شما هدیه تعلق میگیرد

👥 تعداد زیر مجموعه ها : $member
💰 موجودی حساب شما : $coin تومان",
	'parse_mode'=>'Markdown',
	  	]);
$connect->query("UPDATE `user` SET `member` = '$member' , `coin` = '$coin' WHERE `id` = '$prameter' LIMIT 1");	
			}else {

    bot('answercallbackquery', [
      'callback_query_id' => $callback_query_id,
      'text' => "❌ هنوز داخل کانال « @$channel » عضو نیستی",
      'show_alert' => true
    ]);
  }
}
//===========================// back //===========================
elseif($text == 'انصراف' or $text == 'Cancel'){
  if( $user['language'] == "fa" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید:",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$home
            ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}else{
if( $user['language'] == "en" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🖥 Main Page

Select a section to continue:",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$homeen
            ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
//===========================// api command //===========================
elseif($text == '/api'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Soon 💥",
            ]);
}
//===========================// coin step //===========================
elseif($user['step'] == 'sendcoin'){
  $coin = $user['coin'] - $user['data'];
  $connect->query("UPDATE user SET step = 'none' , coin = '$coin' WHERE id = '$from_id' LIMIT 1");
      bot('sendmessage',[       
      'chat_id'=>$chat_id,
      'text'=>"✅ انتقال موجودی با موفقیت انجام شد
      
↗️ موجودی انتقال داده شده  : {$user['data']}
💰 موجودی جدید شما : $coin تومان
👤 کاربر مورد نظر : [$text](tg://user?id=$text)",
          'parse_mode'=>'Markdown',
          'reply_to_message_id'=>$message_id,
          'reply_markup'=>$home
           ]);
 $userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$text' LIMIT 1"));
 $coin = $userdata['coin'] + $user['data'];
       bot('sendmessage',[       
      'chat_id'=>$text,
      'text'=>"✅ {$user['data']} تومان موجودی از طرف [$from_id](tg://user?id=$from_id) برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin تومان",
          'parse_mode'=>'Markdown',
           ]);
 $connect->query("UPDATE user SET coin = '$coin' WHERE id = '$text' LIMIT 1");
 $coinsender = $user['coin'] - $user['data'];
 $coinsenderold = $coinsender + $user['data'];
 $coincollecter = $userdata['coin'] + $user['data'];
 $coincollecterold = $coincollecter - $user['data'];
         bot('sendmessage',[       
      'chat_id'=>"@{$setting['channelenteghalat']}",
      'text'=>"✅ #انتقال موجودی جدیدی انجام شد
      
↗️ موجودی انتقال داده شده  : {$user['data']} تومان

➖➖➖➖➖➖➖➖➖⭐️➖➖➖➖➖➖➖➖➖

👤 کاربر ارسال کننده : [$chat_id](tg://user?id=$chat_id)
👤 کاربر دریافت کننده : [$text](tg://user?id=$text)

➖➖➖➖➖➖➖➖➖⭐️➖➖➖➖➖➖➖➖➖

💰 موجودی قدیم انتقال دهنده : $coinsenderold تومان
💰 موجودی جدید انتقال دهنده : $coinsender تومان

💰 موجودی قدیم دریافت کننده : $coincollecterold تومان
💰 موجودی جدید دریافت کننده : $coincollecter تومان

➖➖➖➖➖➖➖➖➖⭐️➖➖➖➖➖➖➖➖➖

`$dateji $timeji`",
          'parse_mode'=>'MarkDown',
           ]);
}
elseif($user['step'] == 'sendcoinen'){
  $coin = $user['coin'] - $user['data'];
  $connect->query("UPDATE user SET step = 'none' , coin = '$coin' WHERE id = '$from_id' LIMIT 1");
      bot('sendmessage',[       
      'chat_id'=>$chat_id,
      'text'=>"✅ Inventory transfer completed successfully
      
↗️ Transferred inventory  : {$user['data']}
💰 Your new inventory : $coin Toman
👤 The desired user : [$text](tg://user?id=$text)",
          'parse_mode'=>'Markdown',
          'reply_to_message_id'=>$message_id,
          'reply_markup'=>$home
           ]);
/*
@Sourrce_Kade
*/  
 $userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$text' LIMIT 1"));
 $coin = $userdata['coin'] + $user['data'];
       bot('sendmessage',[       
      'chat_id'=>$text,
      'text'=>"✅ {$user['data']} Inventory from [$from_id](tg://user?id=$from_id) Transferred to you.
💰 Your new inventory : $coin Toman",
          'parse_mode'=>'Markdown',
           ]);
 $connect->query("UPDATE user SET coin = '$coin' WHERE id = '$text' LIMIT 1");
}
elseif ($user['step'] == 'seenpost') {
    if($message->audio != true){
      $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    if($message->forward_from_chat == true){
      $id = bot('ForwardMessage',[
      'chat_id'=>"@$channelorder",   
      'from_chat_id'=>$from_id,
      'message_id'=>$message_id,
      ])->result->message_id;
      $link = "https://t.me/$channelorder/$id";
    }else{
      $exlink = explode('/', $text);
      $channelorder = $exlink[count($exlink) - 2];
      $id = end($exlink);
      $link = "https://t.me/$channelorder/$id";
    } 
      $explode = explode('^',$user['data']);
      $result = file_get_contents("$webapi/?apikey=$apikey&type=view&count=$explode[0]&speed=0&period=0&channel=@$channelorder&id=$id");
      $result1 = json_decode($result,true);
      $resul1t = $result1["result"];
      $order_id = $result1["order"];
      $seenstart = $result->seenstart;
	  $seenstart = $result1["seenstart"];
      if($resul1t == 'ok'){
      $amount = $explode[0] * $setting['seen'];
      $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$from_id' LIMIT 1");  
      $startorder = ($explode[1] == 0)?'فوری':"بعد از $explode[1] دقیقه";
      $speed = ($explode[2] == 0)?'حداکثر سرعت':"هر $explode[2] دقیقه $explode[3] بازدید";
      bot('sendmessage',[
      'chat_id'=>$chat_id,
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .
    
    ⚡️ سرعت تکمیل : $speed
    ⏱ زمان شروع سفارش : $startorder
    💰 هزینه سفارش : $amount تومان
    👁‍🗨 تعداد بازدید درخواستی : $explode[0]
    👁 بازدید فعلی : $seenstart",
    'reply_to_message_id'=>$message_id,
        'reply_markup'=>$home
                ]);
    $connect->query("INSERT INTO `orderseen` (`key` , `id` , `amount` , `speed` , `view` , `link` , `time`) VALUES ('$order_id' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");    
	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .
    
    ⚡️ سرعت تکمیل : $speed
    ⏱ زمان شروع سفارش : $startorder
    💰 هزینه سفارش : $amount تومان
    👁‍🗨 تعداد بازدید درخواستی : $explode[0]
    👁 بازدید فعلی : $seenstart
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
    }else{
    bot('sendmessage',[
      'chat_id'=>$chat_id,
      'text'=>"❗️ خطا ، پست شما نامعتبر است یا مشکلی در انجام سفارش ایجاد شده است
    ⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید
    
    👮🏻 در صورت بروز هرگونه مشکل و یا انجام نشدن سفارش کافیست با پشتیبانی در تماس باشید .",
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
                ]);
        $connect->query("UPDATE `user` SET `step` = 'seenpost' WHERE `id` = '$from_id' LIMIT 1");      
    }
    }else      
    bot('sendphoto',[
      'chat_id'=>$chat_id,
      'photo'=>'https://t.me/justfortestjiji/959',
      'caption'=>'❗️ پست ارسال شده معتبر نیست
    
    🎵 در صورتی که مایلید پست موسیقی را ثبت کنید، توجه داشته باشید به جای فوروارد، لینک پست مورد نظر را ارسال کنید .
    ⚠️ توجه کنید که در صورتی که کپی کردن لینک وجود ندارد , باید از تلگرام های رسمی و متعبر استفاده کنید',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
                ]);  
    }
	
	
	elseif ($user['step'] == 'seenposten') {
    if($message->audio != true){
      $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    if($message->forward_from_chat == true){
      $id = bot('ForwardMessage',[
      'chat_id'=>"@$channelorder",   
      'from_chat_id'=>$from_id,
      'message_id'=>$message_id,
      ])->result->message_id;
      $link = "https://t.me/$channelorder/$id";
    }else{
      $exlink = explode('/', $text);
      $channelorder = $exlink[count($exlink) - 2];
      $id = end($exlink);
      $link = "https://t.me/$channelorder/$id";
    } 
      $explode = explode('^',$user['data']);
      $result = file_get_contents("$webapi/?apikey=$apikey&type=view&count=$explode[0]&speed=0&period=0&channel=@$channelorder&id=$id");
      $result1 = json_decode($result,true);
      $resul1t = $result1["result"];
      $order_id = $result1["order"];
      $seenstart = $result->seenstart;
	  $seenstart = $result1["seenstart"];
      if($resul1t == 'ok'){
      $amount = $explode[0] * $setting['seen'];
      $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$from_id' LIMIT 1");  
      $startorder = ($explode[1] == 0)?'instantaneous':"after $explode[1] Minutes";
      $speed = ($explode[2] == 0)?'Maximum speed':"Any $explode[2] Minutes $explode[3] Visit";
      bot('sendmessage',[
      'chat_id'=>$chat_id,
        'text'=>"✅️ Order a visit with a tracking number $order_id it is registered .
    
    ⚡️ Completion speed : $speed
    ⏱ Order start time : $startorder
    💰 Order cost : $amount Toman
    👁‍🗨 Number of visits requested : $explode[0]
    👁 Current visits : $seenstart",
    'reply_to_message_id'=>$message_id,
        'reply_markup'=>$homeen
                ]);    
    $connect->query("INSERT INTO `orderseen` (`key` , `id` , `amount` , `speed` , `view` , `link` , `time`) VALUES ('$order_id' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");    
	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .
    
    ⚡️ سرعت تکمیل : $speed
    ⏱ زمان شروع سفارش : $startorder
    💰 هزینه سفارش : $amount تومان
    👁‍🗨 تعداد بازدید درخواستی : $explode[0]
    👁 بازدید فعلی : $seenstart
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
	}else{
    bot('sendmessage',[
      'chat_id'=>$chat_id,
      'text'=>'❗️ Error, your post is invalid or there is a problem ordering
    ⬅️ Forward the desired post from the channel to the robot to increase traffic
    
    👮🏻 In case of any problems or the order is not fulfilled, just contact the support .',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$backen
                ]);
        $connect->query("UPDATE `user` SET `step` = 'seenposten' WHERE `id` = '$from_id' LIMIT 1");      
    }
    }else      
    bot('sendphoto',[
      'chat_id'=>$chat_id,
      'photo'=>'https://t.me/justfortestjiji/959',
      'caption'=>'❗️ The post sent is not valid
    
    🎵 If you want to submit a music post, note that instead of forwarding, send the link to the desired post.
    ⚠️ Note that if there is no copy of the link, you must use official and express telegrams',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$backen
                ]);  
    }
	

    elseif(preg_match('/^bu_(.*)/', $data) and $user['step'] == 'likebutton'){  
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
        bot('deletemessage',['chat_id'=> $chatid,'message_id'=> $messageid ]);
        $explode = explode('^',$user['data']);
        $match = explode('_',$data,4);
        $assd = $explode[2];
        $sndf = $explode[3];
        $link = "https://t.me/$explode[2]/$explode[3]";
		$result = curl("$webapi/?apikey=$apikey&type=like&count=$explode[0]&row=$match[1]&column=$match[2]&channel=@$assd&id=$sndf");
        if($result->result == 'ok'){
        $amount = $explode[0] * $setting['like'];
        $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$fromid' LIMIT 1");
        $speed = ($explode[1] == 1)?'حداکثر سرعت':"هر $explode[1] دقیقه 1 لایک";
        bot('sendmessage',[
        'chat_id'=>$chatid,
          'text'=>"☑️ سفارش لایک (رأی) با شماره پیگیری {$result->order} ثبت شد .
      
      ⚡️ سرعت تکمیل : $speed
      💰 هزینه سفارش : $amount تومان
      👍🏻 تعداد درخواست لایک : $explode[0]
      ✅ گزینه انتخابی : $match[3]",
          'reply_markup'=>$home
                  ]);    
      $connect->query("INSERT INTO `orderlike` (`key` , `id` , `amount` , `speed` ,`like` , `link` , `time`) VALUES ('{$result->order}' ,'$fromid' , '$amount' , '$speed' , '$explode[0]' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");    
      	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش لایک (رأی) با شماره پیگیری {$result->order} ثبت شد .
      
      ⚡️ سرعت تکمیل : $speed
      💰 هزینه سفارش : $amount تومان
      👍🏻 تعداد درخواست لایک : {$explode[0]}
      ✅ گزینه انتخابی : {$match[3]}
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
	  }else{
      bot('sendmessage',[
        'chat_id'=>$chatid,
        'text'=>"❗️ خطا ، مشکلی در انجام سفارش ایجاد شده است
      ⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید
      
      👮🏻 در صورت بروز هرگونه مشکل و یا انجام نشدن سفارش کافیست با پشتیبانی در تماس باشید .",
          'reply_markup'=>$back
                  ]);
        $connect->query("UPDATE `user` SET `step` = 'likebutton' WHERE `id` = '$fromid' LIMIT 1");
      } 
      }
	  
	 
elseif(preg_match('/^bu_(.*)/', $data) and $user['step'] == 'likebuttonen'){  
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
        bot('deletemessage',['chat_id'=> $chatid,'message_id'=> $messageid ]);
        $explode = explode('^',$user['data']);
        $match = explode('_',$data,4);
        $assd = $explode[2];
        $sndf = $explode[3];
        $link = "https://t.me/$explode[2]/$explode[3]";
        $result = curl("$webapi/?apikey=$apikey&type=like&count=$explode[0]&row=$match[1]&column=$match[2]&channel=@$assd&id=$sndf");
        if($result->result == 'ok'){
        $amount = $explode[0] * $setting['like'];
        $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$fromid' LIMIT 1");
        $speed = ($explode[1] == 1)?'حداکثر سرعت':"هر $explode[1] دقیقه 1 لایک";
        bot('sendmessage',[
        'chat_id'=>$chatid,
          'text'=>"✅️ Order likes (votes) with tracking number {$result->order} it is registered .
      
      ⚡️ Completion speed : $speed
      💰 Order cost : $amount Toman
      👍🏻 Number of likes : $explode[0]
      ✅ Optional option : $match[3]",
          'reply_markup'=>$homeen
                  ]);    
      $connect->query("INSERT INTO `orderlike` (`key` , `id` , `amount` , `speed` ,`like` , `link` , `time`) VALUES ('{$result->order}' ,'$fromid' , '$amount' , '$speed' , '$explode[0]' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");    
      }else{
      bot('sendmessage',[
        'chat_id'=>$chatid,
        'text'=>'❗️ An error occurred while ordering
      ⬅️ Forward the desired post (poll) to the bot to increase the likes (votes) from a public channel
      
      👮🏻 In case of any problems or the order is not fulfilled, just contact the support .',
          'reply_markup'=>$backen
                  ]);  
        $connect->query("UPDATE `user` SET `step` = 'likebuttonen' WHERE `id` = '$fromid' LIMIT 1");
      } 
      }
	  
//===========================
elseif ($user['step'] == 'seentpost') {
    if($message->audio != true){
	$explode = explode('^',$user['data']);
    $amount = $explode[0] * $setting['seen'];
    if($user['coin'] >= $amount){
      $connect->query("UPDATE `user` SET `step` = 'seentpost WHERE `id` = '$from_id' LIMIT 1");
    if($message->forward_from_chat == true){
      $id = bot('ForwardMessage',[
      'chat_id'=>"@$channelorder",   
      'from_chat_id'=>$from_id,
      'message_id'=>$message_id,
      ])->result->message_id;
      $link = "https://t.me/$channelorder/$id";
    }else{
      $exlink = explode('/', $text);
      $channelorder = $exlink[count($exlink) - 2];
      $id = end($exlink);
      $link = "https://t.me/$channelorder/$id";
    } 
      $explode = explode('^',$user['data']);
      $result = file_get_contents("$webapi/?apikey=$apikey&type=view&count=$explode[0]&speed=0&period=0&channel=@$channelorder&id=$id");
      $result1 = json_decode($result,true);
      $resul1t = $result1["result"];
      $order_id = $result1["order"];
	  $seenstart = $result1["seenstart"];
      if($resul1t == 'ok'){
      $amount = $explode[0] * $setting['seen'];
      $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$from_id' LIMIT 1");  
      $startorder = ($explode[1] == 0)?'فوری':"بعد از $explode[1] دقیقه";
      $speed = ($explode[2] == 0)?'حداکثر سرعت':"هر $explode[2] دقیقه $explode[3] بازدید";
      bot('sendmessage',[
      'chat_id'=>$chat_id,
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .
    
    ⚡️ سرعت تکمیل : $speed
    ⏱ زمان شروع سفارش : $startorder
    💰 هزینه سفارش : $amount تومان
    👁‍🗨 تعداد بازدید درخواستی : $explode[0]
    👁 بازدید فعلی : $seenstart",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
                ]);    
    $connect->query("INSERT INTO `orderseen` (`key` , `id` , `amount` , `speed` , `view` , `link` , `time`) VALUES ('$order_id' ,'$from_id' , '$amount' , '$speed' , '$explode[0]' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");    
    $connect->query("UPDATE `user` SET `step` = 'seentpost' WHERE `id` = '$from_id' LIMIT 1");
    	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید با شماره پیگیری $order_id ثبت شد .
    
    ⚡️ سرعت تکمیل : $speed
    ⏱ زمان شروع سفارش : $startorder
    💰 هزینه سفارش : $amount تومان
    👁‍🗨 تعداد بازدید درخواستی : $explode[0]
    👁 بازدید فعلی : $seenstart
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
	}else{
    bot('sendmessage',[
      'chat_id'=>$chat_id,
      'text'=>'❗️ خطا ، پست شما نامعتبر است یا مشکلی در انجام سفارش ایجاد شده است
    ⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید
    
    👮🏻 در صورت بروز هرگونه مشکل و یا انجام نشدن سفارش کافیست با پشتیبانی در تماس باشید .',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
                ]);
        $connect->query("UPDATE `user` SET `step` = 'seentpost' WHERE `id` = '$from_id' LIMIT 1");      
    }
    }else      
      bot('sendmessage',[
      'chat_id'=>$chat_id,
      'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش نیاز به حداقل $amount تومان موجودی دارید .
 
💰 موجودی حساب شما : {$user['coin']} تومان",
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
                        ]);
    }else{
    bot('sendphoto',[
      'chat_id'=>$chat_id,
      'photo'=>'https://t.me/justfortestjiji/959',
      'caption'=>'❗️ پست ارسال شده معتبر نیست
    
    🎵 در صورتی که مایلید پست موسیقی را ثبت کنید، توجه داشته باشید به جای فوروارد، لینک پست مورد نظر را ارسال کنید .
    ⚠️ توجه کنید که در صورتی که کپی کردن لینک وجود ندارد , باید از تلگرام های رسمی و متعبر استفاده کنید',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
                ]);
}}
//===========================// language //===========================
elseif($text == '/language'){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]);	
}
elseif($text == '🇮🇷 فارسی'){
$connect->query("UPDATE `user` SET `language` = 'fa' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$start,
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home,
            ]);	
}
elseif($text == '🏴󠁧󠁢󠁥󠁮󠁧󠁿 English'){
$connect->query("UPDATE `user` SET `language` = 'en' WHERE `id` = '$from_id' LIMIT 1");
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$starten,
'reply_to_message_id'=>$message_id,
'reply_markup'=>$homeen,
            ]);	
}
//===========================// join //===========================
elseif(bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$from_id])->result->status == 'left'){
 bot('sendmessage',[
        'chat_id'=>$chat_id,
        "text"=>"☑️ برای استفاده از ربات « $botname » ابتدا باید وارد کانال  « $channelname » شوید
❗️ برای دریافت آموزش ها ،  اطلاعیه ها و گزارشات شما باید عضو کانال ربات شوید
		
📣 @$channel

👇 بعد از عضویت در کانال روی دکمه « ✅ تایید عضویت » بزنید 👇",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
			[['text'=>'✅ تایید عضویت','callback_data'=>'join']],
              ]
        ])
			]);
if($user['id'] != true) {
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>$gift,
    		]);
$connect->query("INSERT INTO `user` (`id` , `coin`) VALUES ('$from_id' , '{$setting['gift']}')");
}
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
//========================== // order // ==============================

elseif($text == '👁 افزایش بازدید'){
if($user['coin'] >= 5){
$max = floor($user['coin'] / $setting['seen']);
$meghdarbazdid = $setting['seen'] * 1000;
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👁‍ تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید 👇🏻
	
❗️ موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .
• هزینه هر 1000 بازدید برابر با $meghdarbazdid تومان است

- برای ثبت ویو همزمان از دستور /viewv2 استفاده کنید -",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenamount' WHERE `id` = '$from_id' LIMIT 1");
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش نیاز به حداقل 5 تومان موجودی دارید .
💰 موجودی حساب شما : {$user['coin']} تومان",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '👁 View'){
if($user['coin'] >= 5){
$max = floor($user['coin'] / $setting['seen']);
$bazdid = $setting['seen'] * 1000;
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👁‍ The desired number of visits as a number between 100 to $result Enter 👇🏻
	
❗️ Your account balance {$user['coin']} Rs and you can max $max Order a visit.
• The cost per 1000 visits is equal to $bazdid Is Tomans",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenamounten' WHERE `id` = '$from_id' LIMIT 1");
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Your account balance is not enough, you need at least 5 Tomans balance to place an order.
💰 Your account balance : {$user['coin']} Toman",
    'reply_to_message_id'=>$message_id,
            ]);	
}

elseif($text == '/viewv2'){
if($user['coin'] >= 5){
$max = floor($user['coin'] / $setting['seen']);
$bazdid = $setting['seen'] * 1000;
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👈🏻 در این بخش شما میتوانید برای چندین پست به صورت همزمان سفارش ثبت کنید
👁‍ تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید 👇🏻
 
❗️ موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .
• هزینه هر 1000 بازدید برابر با $bazdid تومان است",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seentamount' WHERE `id` = '$from_id' LIMIT 1");
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش نیاز به حداقل 5 تومان موجودی دارید .
💰 موجودی حساب شما : {$user['coin']} تومان",
    'reply_to_message_id'=>$message_id,
            ]);	
}

elseif($text == '❤️ افزایش لایک'){
if($user['coin'] >= $setting['like']){
$max = floor($user['coin'] / $setting['like']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👍🏻 تعداد لایک (رأی) مورد نظر را به صورت عددی بین 1 الی $result وارد کنید 👇🏻
	
• با استفاده از این بخش میتوانید برای تمامی پستها ، لایک و رأی سفارش دهید به شرط آنکه پست در کانال عمومی باشد و یا یک نظر سنجی (Poll) باشد .
	
❗️ موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max لایک را سفارش دهید
🎁 با ثبت سفارش لایک ، پست مربوطه به همان مقدار بازدید هم خواهد خورد
• هزینه هر عدد لایک برابر با {$setting['like']} تومان است",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'likeamount' WHERE `id` = '$from_id' LIMIT 1");
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش لایک نیاز به حداقل {$setting['like']} تومان موجودی دارید .
💰 موجودی حساب شما : {$user['coin']} تومان",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '❤️ Like'){
if($user['coin'] >= $setting['like']){
$max = floor($user['coin'] / $setting['like']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👍🏻 The desired number of likes (votes) numerically between 100 to $result enter 👇🏻
	
• Using this section, you can order for all posts, likes and votes, provided that the post is in the public channel or is a poll (Poll). .
	
❗️ Your account balance {$user['coin']} Rs and you can max $max Order Like
🎁 By registering a Like order, the relevant post will receive the same amount of views
• The cost of each number of likes is equal to {$setting['like']} Is Tomans",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'likeamounten' WHERE `id` = '$from_id' LIMIT 1");
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Your account balance is not enough, you need a minimum to place a like order {$setting['like']} You have a balance of Tomans.
💰 Your account balance : {$user['coin']} Toman",
    'reply_to_message_id'=>$message_id,
            ]);	
}
/*
@Sourrce_Kade
*/
//===================================

elseif($text == '👍 ری‌اکشن'){
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"👈 تعداد ری‌اکشن دلخواه خود را بین 1 الی $result ارسال کنید.
موجودی شما: {$user['coin']} سکه

* هزینه هر ری‌اکشن معادل {$setting['reaction']} سکه است.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
]);
$connect->query("UPDATE `user` SET `step` = 'reactionamount' WHERE `id` = '$from_id' LIMIT 1");
}
   elseif($user['step'] == 'reactionamount'){
     if($user['coin'] >= $text * $setting['reaction'] ){	
	 if (is_numeric($text)) {
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

همواره لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'حداکثر سرعت']],
		[['text'=>'انصراف']],
		],
          'resize_keyboard'=>true
          ])
         ]);	
$connect->query("UPDATE `user` SET `step` = 'reactinspeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else{
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⚠️ لطفا فقط عدد وارد کنید.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}
}else{
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⚠️ موجودی شما کافی نیست.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}
}
elseif ($user['step'] == 'reactinspeed') {
$speedpanel = ['حداکثر سرعت'];
$explode = explode('^',$user['data']);
if(in_array($text , $speedpanel)){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👈 لطفا لینک پست را برای افزایش ری‌اکشن ارسال کنید.

تعداد درخواست: $explode[0] ری‌اکشن
شروع سفارش: فوری
سرعت تکمیل: حداکثر سرعت",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
	]);		
$keys = [$speedpanel[0]=>'0'];
$connect->query("UPDATE `user` SET `step` = 'reactionpost' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}else{
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ سرعت انجام سفارش را با استفاده از دکمه های نمایش داده شده انتخاب نمایید.

همواره لیست آخرین سرعتهای تنظیم شده توسط شما در زیر نمایش داده میشود.',
    'reply_to_message_id'=>$message_id,
        'keyboard'=>[
		[['text'=>'حداکثر سرعت']],
		[['text'=>'انصراف']],
		],
          'resize_keyboard'=>true,
            ]);				
}
}
elseif ($user['step'] == 'reactionpost') {
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'🎯 ری‌اکشن موردنظر را انتخاب کنید:

توجه: برای درخواست ری‌اکشن‌های پریمیوم، این ری‌اکشن‌ها باید حداقل یک بار برای پست ثبت شده باشند!

ری‌اکشن‌های پریمیوم: 👌🤡🥱😍🥴🐳❤️‍🔥🌚🌭💯🤣🕊',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=> json_encode([
        'inline_keyboard' => [
      [['text' => '👍', 'callback_data' => "reaction_1"],['text' => '👎', 'callback_data' => "reaction_2"],['text' => '❤️', 'callback_data' => "reaction_3"]],
      [['text' => '🔥', 'callback_data' => "reaction_4"],['text' => '🎉', 'callback_data' => "reaction_5"],['text' => '🤩', 'callback_data' => "reaction_6"],['text' => '😱', 'callback_data' => "reaction_7"]],
      [['text' => '😁', 'callback_data' => "reaction_8"],['text' => '😢', 'callback_data' => "reaction_9"],['text' => '💩', 'callback_data' => "reaction_10"],['text' => '🤮', 'callback_data' => "reaction_11"]],
        ]
      ])
            ]);
            if($message->forward_from_chat == true){
            $m_ch = $message->forward_from_message_id;
            $ch =$message->forward_from_chat->username;
            }else{
      $exlink = explode('/', $text);
      $ch = $exlink[count($exlink) - 2];
      $m_ch = end($exlink);
    
    } 
            $connect->query("UPDATE `user` SET `step` = 'reactionpost2' , `data` = CONCAT(`data`,'^$ch^$m_ch') WHERE `id` = '$from_id' LIMIT 1");
}   
elseif($data == 'back'){
	bot('deleteMessage', [
        'chat_id'=>$chatid, 
        'message_id'=>$messageid, 
        ]);
	bot('deleteMessage', [
        'chat_id'=>$chatid, 
        'message_id'=>$messageid-1, 
        ]);
	bot('sendmessage',[
        'chat_id'=>$chatid,
        'text'=>'🖥 صفحه اصلی

برای ادامه کار یک بخش را انتخاب کنید:',
    'reply_markup'=>$home
    ]);
    $connect->query("UPDATE user SET `step`='none',`data`='none' WHERE id='$fromid' LIMIT 1");
}
elseif(preg_match('/^reaction_(.*)/', $data) and $user['step'] == 'reactionpost2' ){
$match = explode('_',$data);
$ex = explode('^',$user['data']);
$a = [1 => '👍',2 => '👎',3 => '❤️',4 => '🔥',5 => '🎉',6 => '🤩'
,7 => '😱',8 => '😁',9 => '😢',10 => '💩',11 => '🤮'];
$Reaction = $a[$match[1]];
bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"
	درخواست ری‌اکشن برای: $Reaction 

تعداد درخواست: $ex[0] ری‌اکشن
شروع سفارش: فوری
سرعت تکمیل: حداکثر سرعت

موارد بالا را تایید میکنید؟",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=> json_encode([
        'inline_keyboard' => [
      [['text' => 'بله', 'callback_data' => "Yes"],['text' => 'خیر', 'callback_data' => "back"]],
        ]
      ])
      ]);
      $connect->query("UPDATE `user` SET `step` = 'reactionpost3' , `data` = CONCAT(`data`,'^$match[1]') WHERE `id` = '$from_id' LIMIT 1");
}
elseif($data == 'Yes' and $user['step'] == 'reactionpost3'){  
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$fromid' LIMIT 1");
$explode = explode('^',$user['data']);
$match= $explode[4];
$link = "https://t.me/$explode[2]/$explode[3]";

$a = [1 => '👍',2 => '👎',3 => '❤️',4 => '🔥',5 => '🎉',6 => '🤩'
,7 => '😱',8 => '😁',9 => '😢',10 => '💩',11 => '🤮'];
$Reaction = $a[$match];

$result = curl("$webapi/?apikey=$apikey&type=reaction&count=$explode[0]&emoji=$Reaction&channel=@$explode[2]&id=$explode[3]");

bot('deleteMessage', [
        'chat_id'=>$chatid, 
        'message_id'=>$messageid, 
        ]);
	    bot('deleteMessage', [
        'chat_id'=>$chatid, 
        'message_id'=>$messageid-1, 
        ]);

if($result->result == 'ok'){
   $amount = $explode[0] * $setting['reaction'];
        $connect->query("UPDATE `user` SET `coin` = `coin` - $amount WHERE `id` = '$fromid' LIMIT 1");
		$connect->query("INSERT INTO `orderreaction` (`key` , `id` , `amount` , `link` , `time`) VALUES ('{$result->order}' ,'$fromid' , '$amount' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");
 
    bot('sendmessage',[
        'chat_id'=>$chatid,
        'text'=>"☑️ سفارش شما با کد پیگیری {$result->order} ثبت شد.

ری اکشن درخواستی : $Reaction
تعداد درخواست: $explode[0] ری‌اکشن
شروع سفارش: فوری
سرعت تکمیل: حداکثر سرعت",
        'reply_markup'=>$home
        ]);
}else{
bot('sendmessage',[
        'chat_id'=>$chatid,
        'text'=>'❗️ خطا ، پست شما نامعتبر است یا مشکلی در انجام سفارش ایجاد شده است',
        'reply_markup'=>$home
        ]);
}
}

# -- =============================== -- #

//========================== // auto // ==============================
elseif($text == '🤖 بازدید کانال' or $text == '🤖 Auto-view'){
	$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel` WHERE `id` = '$from_id'"));
if( $user['language'] == "fa" ){
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 با استفاده از این بخش میتوانید ربات را به گونه ای تنظیم نمایید تا به محض انتشار پست جدید در کانال، فرایند افزایش بازدید آن به طور خودکار شروع شود.

برای شروع '📢 ثبت کانال جدید' را انتخاب کنید.",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'📢 ثبت کانال جدید']],
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		]),
            ]);	
}else{
		$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel` WHERE `id` = '$from_id'"));
if( $user['language'] == "en" ){
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🤖 Using this section, you can set the robot so that as soon as a new post is published in the channel, the process of increasing its traffic will start automatically.

Select '📢 New Channel' to get started.",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'📢 New Channel']],
		[['text'=>'Cancel']],
		],
        'resize_keyboard'=>true,
       		]),
            ]);	
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '/autoview'){
$order = mysqli_query($connect,"SELECT * FROM `channel` WHERE `id` = '$from_id'");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$explode = explode('^',$row['speed']);
$start = ($explode[0] == 0)?'فوری':"بعد از $explode[0] دقیقه";
$speed = ($explode[1] == 0)?'حداکثر سرعت':"هر $explode[1] دقیقه $explode[2] بازدید";
$title = bot('getchat',['chat_id'=>$row['channel']])->result->title;
$result = $result."✅ نام کانال : $title\n👁‍🗨 تعداد بازدید خودکار : {$row['view']}\n⏱ زمان شروع سفارش : $start\n⚡️ سرعت انجام سفارش : $speed\n❌ برای حذف کانال /del_".abs($row['channel'])."\n━ ━ ━\n";
}
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👇🏻 لیست کانالهای ثبت شده توسط شما
❗️ توجه داشته باشید جزئیات سفارشات ثبت شده در پیگیری سفارشات در دسترس است
	
$result",
    'reply_to_message_id'=>$message_id,
            ]);	
}else
	    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ شما تا کنون کانالی را جهت بازدید خودکار ثبت نکرده اید
👈🏻 برای شروع کافیست از دکمه "📢 ثبت کانال جدید" استفاده نمایید و مراحل را ادامه دهید .',
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '📢 ثبت کانال جدید'){
if($user['coin'] >= 10){
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ برای شروع بازدید خودکار ، لطفا ربات @$usernamebot را در کانال ادمین کرده و سپس یک پست از کانال را به ربات فوروارد نمایید

جهت حذف کانالی از لیست کانال های ثبت شده از دستور /autoview استفاده کنید",
   'parse_mode'=>'HTML',
   'reply_to_message_id'=>$message_id,
   'reply_markup'=>$back,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'setchannel' WHERE `id` = '$from_id' LIMIT 1");
}else
	    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ موجودی حساب شما کافی نمیباشد ، برای انجام سفارش نیاز به حداقل 10 تومان موجودی دارید .
💰 موجودی حساب شما : {$user['coin']} تومان",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '📢 New Channel'){
if($user['coin'] >= 10){
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ To start auto-visit, please robot @$usernamebot Admin in the channel and then forward a post from the channel to the robot

To remove a channel from the list of registered channels from the command /autoview use",
   'parse_mode'=>'HTML',
   'reply_to_message_id'=>$message_id,
   'reply_markup'=>$backen,
            ]);	
$connect->query("UPDATE `user` SET `step` = 'setchannelen' WHERE `id` = '$from_id' LIMIT 1");
}else
	    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Your account balance is not enough, you need at least 10 Tomans balance to place an order.
💰 Your account balance : {$user['coin']} Toman",
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif(preg_match('/^\/del_(.*)/', $text , $match)){
if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `channel` WHERE `id` = '$from_id' AND `channel` = '-$match[1]' LIMIT 1")) == true){
	$title = bot('getchat',['chat_id'=>-$match[1]])->result->title;
	bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>"☑️ کاناله $title با موفقیت از لیست بازدید خودکار حذف شد .",
    'reply_to_message_id'=>$message_id,
    		]);
$connect->query("DELETE FROM `channel` WHERE `channel` = '-$match[1]' LIMIT 1");
}else
		bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❌ خطا ، کانال در لیست بازدید های خودکار وجود ندارد',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home,
    		]);	
}
//========================== // order list // ==============================
elseif($text == '🔎 پیگیری' or $text == '🔎 Tracking'){
$orderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen` WHERE `id` = '$from_id'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike` WHERE `id` = '$from_id'"));
if( $user['language'] == "fa" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👇🏻 بخش مورد نظر را جهت پیگیری و مشاهده سفارشات انتخاب کنید

👁 تعداد سفارشات بازدید : $orderseen
👍🏻 تعداد سفارشات لایک : $orderlike",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'❤️ سفارشات لایک'],['text'=>'👁‍🗨 سفارشات بازدید']],
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		]),
            ]);					
}else{
	$orderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen` WHERE `id` = '$from_id'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike` WHERE `id` = '$from_id'"));
if( $user['language'] == "en" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👇🏻 Select the desired section to track and view orders

👁 Number of visit orders : $orderseen
👍🏻 Number of likes orders : $orderlike",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'❤️ Like orders'],['text'=>'👁‍🗨 View orders']],
		[['text'=>'Cancel']],
		],
        'resize_keyboard'=>true,
       		]),
            ]);					
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '👁‍🗨 View orders'){
$order = mysqli_query($connect,"SELECT * FROM `orderseen` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 10");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 1)?'Completed':'Not completed !';
$result = $result."🆔 Order ID 👈🏻 {$row['key']}\n⚡️ Completion speed : {$row['speed']}\n⏱ Time : {$row['time']}\n💰 Order cost : {$row['amount']} Toman\n👁‍🗨 Number of visits requested : {$row['view']}\n✅ Condition : $stats\n━ ━ ━\n";
}
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛒 List your ten most visited orders
	
$result",
    'reply_to_message_id'=>$message_id,
            ]);	
}else
	 bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ You have not registered a visit order yet
👈🏻 To get started, just use the "👁 View" button in the main menu and continue the steps.',
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '❤️ Like orders'){
$order = mysqli_query($connect,"SELECT * FROM `orderlike` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 10");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 1)?'Completed':'Not completed !';
$result = $result."🆔 Order ID 👈🏻 {$row['key']}\n⚡️ Completion speed : {$row['speed']}\n⏱ Time : {$row['time']}\n💰 Order cost : {$row['amount']} Toman\n👍🏻 Number of likes : {$row['like']}\n✅ Condition : $stats\n━ ━ ━\n";
}
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛒 List the last ten orders you like
	
$result",
    'reply_to_message_id'=>$message_id,
            ]);	
}else
	 bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ You have not registered a Like order yet
👈🏻 To get started, just use the "❤️ Like" button in the main menu and continue the steps.',
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '👁‍🗨 سفارشات بازدید'){
$order = mysqli_query($connect,"SELECT * FROM `orderseen` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 10");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 1)?'تکمیل شده':'تکمیل نشده !';
$result = $result."🆔 شناسه سفارش 👈🏻 {$row['key']}\n⚡️ سرعت تکمیل : {$row['speed']}\n⏱ زمان : {$row['time']}\n💰 هزینه سفارش : {$row['amount']} تومان\n👁‍🗨 تعداد بازدید درخواستی : {$row['view']}\n✅ وضعیت : $stats\n━ ━ ━\n";
}
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛒 لیست ده سفارش بازدید اخیر شما
	
$result",
    'reply_to_message_id'=>$message_id,
            ]);	
}else
	 bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ شما تا کنون سفارش بازدید ثبت نکرده اید
👈🏻 برای شروع کافیست از دکمه "👁 افزایش بازدید" در منوی اصلی استفاده نمایید و مراحل را ادامه دهید .',
    'reply_to_message_id'=>$message_id,
            ]);	
}
elseif($text == '❤️ سفارشات لایک'){
$order = mysqli_query($connect,"SELECT * FROM `orderlike` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 10");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order)){
$stats = ($row['stats'] == 1)?'تکمیل شده':'تکمیل نشده !';
$result = $result."🆔 شناسه سفارش 👈🏻 {$row['key']}\n⚡️ سرعت تکمیل : {$row['speed']}\n⏱ زمان : {$row['time']}\n💰 هزینه سفارش : {$row['amount']} تومان\n👍🏻 تعداد لایک : {$row['like']}\n✅ وضعیت : $stats\n━ ━ ━\n";
}
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛒 لیست ده سفارش اخیر لایک شما
	
$result",
    'reply_to_message_id'=>$message_id,
            ]);	
}else
	 bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ شما تا کنون سفارش لایک ثبت نکرده اید
👈🏻 برای شروع کافیست از دکمه "❤️ افزایش لایک" در منوی اصلی استفاده نمایید و مراحل را ادامه دهید .',
    'reply_to_message_id'=>$message_id,
            ]);	
}
//========================== // charge amount // ==============================
elseif($text == '➕ افزایش موجودی' or $text == '➕ Buy coins'){
$allbuy = mysqli_num_rows(mysqli_query($connect,"select id from buy WHERE id = '$from_id'"));
if( $user['language'] == "fa" ){
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"یک بخش را جهت افزایش موجودی انتخاب کنید:",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
    [['text'=>'👥 زیرمجموعه'],['text'=>'📥 ارسال اکانت'],['text'=>'💵 خرید']],
    [['text'=>'انصراف']],
    ],
        'resize_keyboard'=>true,
           ])
            ]);          
}else{
  $allbuy = mysqli_num_rows(mysqli_query($connect,"select id from buy WHERE id = '$from_id'"));
if( $user['language'] == "en" ){
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"Select a section to increase inventory:",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
    [['text'=>'👥 subset'],['text'=>'📥 Send an account'],['text'=>'💵 Buy']],
    [['text'=>'Cancel']],
    ],
        'resize_keyboard'=>true,
           ])
            ]);          

}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '💵 خرید' ){
  if( $user['activeuser'] == "1"){
	$bazdid = $setting['seen'] * 1000;
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👇🏻 برای افزایش موجودی حساب مبلغ موردنظر خود را به تومان وارد نمایید

❗️ توجه کنید که مبلغ را به عدد وارد کنید و حداقل میتوانید {$setting['hadaghalkharid']} و حداکثر {$setting['hadaksarkharid']} تومان حساب خود را شارژ کنید

👈🏻  تعرفه هر 1000 بازدید 👁‍🗨 $bazdid تومان 
👈🏻  تعرفه هر 1 لایک ❤️ {$setting['like']} تومان 
👈🏻 تعرفه هر 1 ری اکشن 👍 {$setting['reaction']} تومان",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		])
            ]);
$connect->query("UPDATE `user` SET `step` = 'pay' WHERE `id` = '$from_id' LIMIT 1");
}else{
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🔐 در راستای افزایش هر چه بیشتر امنیت در پرداخت ها، لطفا شماره همراه خود را ارسال نمایید.

☑️ برای تایید شماره از دکمه '🔐 ارسال شماره' استفاده کنید

❗️ شماره ارسالی نزد ما محفوظ است و هیچکس امکان دسترسی به آن را ندارد.
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🔐 ارسال شماره",'request_contact' =>true]],
[['text'=>'انصراف']],
],
'resize_keyboard'=>true
])
]);  
$connect->query("UPDATE user SET step = 'oknum' WHERE id = '$from_id' LIMIT 1");
}}

elseif(isset($update->message->contact->phone_number) and $user['step'] == 'oknum'){
if(preg_match('/^(98|\+98)(.*)/',$update->message->contact->phone_number)){
if($update->message->contact->user_id == $from_id){    
$phone = $update->message->contact->phone_number;
$phone = str_replace("+98","0",$phone);
$rand = rand(1000,9999);
file_get_contents("https://api.codebazan.ir/sms/api.php?type=sms&apikey=$apisms&code=$rand&phone=$phone");
$connect->query("UPDATE `user` SET `codeveri` = '$rand' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE user SET step = 'oknum2' WHERE id = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `fakenumber` = '$phone' WHERE `id` = '$from_id' LIMIT 1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔢 کد تایید تا چند ثانیه دیگر به شماره همراه شما پیامک میشود و تا 2 دقیقه اعتبار دارد.
👈 لطفا کد 4 رقمی دریافتی را وارد نمایید :
"]);
}
}else{

  $connect->query("UPDATE user SET step = 'oknum' WHERE id = '$from_id' LIMIT 1");
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔐 در راستای افزایش هر چه بیشتر امنیت در پرداخت ها، لطفا شماره همراه خود را ارسال نمایید.

☑️ برای تایید شماره از دکمه '🔐 ارسال شماره' استفاده کنید

❗️ شماره ارسالی نزد ما محفوظ است و هیچکس امکان دسترسی به آن را ندارد.
",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>"🔐 ارسال شماره",'request_contact' =>true]],
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		])
            ]);
}
}
elseif($user['step'] == 'oknum2'){
if( $user['codeveri'] == $text){
$numberus = $user['fakenumber'];
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ تبریک، شماره شما تایید شد و میتوانید از تمامی امکانات ربات استفاده نمایید.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$home,
            ]); 
bot('sendMessage',[
'chat_id'=>$setting['channelsabtnumber'],
'text'=>"
📍 یک شماره جدید در سیستم ثبت شد.

+ ثبت نام کننده : $from_id
+ شماره تلفن شما : $numberus
+ زمان ثبت : `$dateji` در ساعت `$timeji`

`$botname`",
'parse_mode'=>'Markdown',
            ]); 
$connect->query("UPDATE `user` SET `phone` = '$numberus' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `activeuser` = '1' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}else{
bot('sendmessage',[
'chat_id' => $chat_id,
'text' => "
❌ کد وارد شده اشتباه میباشد لطفا مجدد تلاش کنید
",
]);
}
}

elseif($text == '💵 Buy'){
$bazdid = $setting['seen'] * 1000;
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👇🏻 To increase your account balance, enter your desired amount in Tomans

❗️ Note that enter the amount in the number and you can charge your account at least 1000 and at most 200000 Tomans

👈🏻 Tariff per 1000 hits 👁‍🗨 $bazdid Toman 
👈🏻 Tariff for every 1 like ❤️ {$setting['like']} Toman",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'Cancel'],['text'=>'💳 Offline payment']],
		],
        'resize_keyboard'=>true,
       		])
            ]);
$connect->query("UPDATE `user` SET `step` = 'pay' WHERE `id` = '$from_id' LIMIT 1");
}

elseif($text == '👥 زیرمجموعه' or $text == '👥 subset'){
if( $user['language'] == "fa" ){
	$id = bot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>$baner,
	'caption'=>"⚡️ با $botname به راحتی بازدید بگیرید 
	
👁‍🗨 افزایش بازدید پستهای تلگرامی
❤️ افزایش لایک و رأی تلگرام
👍 افزایش ری اکشن پستهای تلگرامی

🕓 با قابلیت تنظیم سرعت و زمان 
👥 زیرمجموعه گیری و دریافت هدیه

🔐 پرداخت مطمئن و 100% امن
دارای نماد اعتماد 💎

👇🏻 همین الان وارد این ربات فوق العاده شو

https://t.me/$usernamebot?start=$from_id",
    		])->result->message_id;
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👆🏻 بنر بالا حاوی لینک دعوت شما به ربات است
	
🎁 در صورت خرید توسط کسانی که شما دعوت میکنید {$setting['porsant']} درصد از مبلغ خریداری شده به شما هدیه داده میشود
💰 همچنین با دعوت دوستان به ربات با لینک اختصاصی خود میتوانید به ازای هر نفر {$setting['member']} تومان موجودی دریافت کنید

👥 تعداد زیر مجموعه ها : {$user['member']} نفر",
	'reply_to_message_id'=>$id,
    		]);
}else{
if( $user['language'] == "en" ){
	$id = bot('sendphoto',[
	'chat_id'=>$chat_id,
	'photo'=>$baner,
	'caption'=>"⚡️ With $botname Visit easily
	
👁‍🗨 Increase visits to Telegram posts
❤️ Increase the likes and votes of Telegram
قابلیت Adjustable speed and time
👥 Subscribe and receive gifts
💯 Free, fast, no offline
🔐 Safe and 100% secure payment

👇🏻 Get in this wonderful robot right now

https://t.me/$usernamebot?start=$from_id",
    		])->result->message_id;
    bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👆🏻 The banner above contains the link to invite you to the robot
	
🎁 If purchased by those you invite {$setting['porsant']} You will be given a percentage of the purchased amount as a gift
💰 You can also invite friends to the robot with your own link for each person {$setting['member']} Get a balance of Tomans

☑️ So by subscribing, you can easily get your account balance for free! Increase.

💰 Your account balance : {$user['coin']} Toman
👥 Number of subsets : {$user['member']} person",
	'reply_to_message_id'=>$id,
    		]);
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}	
elseif($text == '💳 پرداخت آفلاین' or $text == '💳 Offline payment'){
if( $user['language'] == "fa" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ℹ️ درصورتی که امکان خرید به صورت آنلاین و با رمز دوم ندارید میتوانید پرداخت را آفلاین انجام دهید

💳 میزان موجودی که نیاز دارید را به صورت کارت به کارت به حساب زیر انتقال دهید .
📲 اسکرین شات پرداخت را برای پشتیبانی ارسال کنید ، تا موجودی حساب شما توسط مدیریت افزایش یابد 👇🏻

$cardinfo",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
            ]);
}else{
if( $user['language'] == "en" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ℹ️ If you can not buy online with a second password, you can make the payment offline

💳 Transfer the amount of balance you need card to card to the following account.
📲 Send payment screenshots for support, to increase your account balance by management 👇🏻

$cardinfo",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen
            ]);
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '📥 ارسال اکانت' or $text == '📥 Send an account'){
if( $user['language'] == "fa" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"با استفاده از این بخش و ربات @$botsendaccount شما میتوانید اکانت مجازی خود را برای ربات ارسال نمایید و در ازای آن تعداد سکه مشخصی دریافت نمایید.

👈 برای شروع به ربات @$botsendaccount رفته و مراحل را انجام دهید.",
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[['text' => "ربات ارسال اکانت", 'url' =>"https://t.me/$botsendaccount"]],
              ]
              ])
	       ]);	
}else{
if( $user['language'] == "en" ){
	  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"Use this section and the robot @$botsendaccount You can send your virtual account to the robot and receive a certain number of coins in return.

👈 To start the robot @$botsendaccount Go and follow the steps.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen
            ]);
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
//========================== // key // ==============================
elseif($text == '👤 حساب من' or $text == '👤 My account'){
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy` WHERE `id` = '$from_id'"));
$orderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen` WHERE `id` = '$from_id'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike` WHERE `id` = '$from_id'"));
$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel` WHERE `id` = '$from_id'"));
if( $user['language'] == "fa" ){
$bazdid = $setting['seen'] * 1000;
$scorebuy = in_array($allbuy,range(0,5)) ? "🌟" : (in_array($allbuy,range(6,20)) ? "🌟🌟" :
(in_array($allbuy,range(21,30)) ? "🌟🌟🌟" : (in_array($allbuy,range(31,50)) ? "🌟🌟🌟🌟" : "🌟🌟🌟🌟🌟")));
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👤شناسه شما : $from_id
👥 زیرمجموعه : {$user['member']} نفر
💰 موجودی شما : {$user['coin']} تومان

🛍 مجموع خرید شما : $allbuy 
🔸 سطح کاربری: $scorebuy

`$botname $dateji $timeji`",
'parse_mode' => 'Markdown',
'reply_to_message_id'=>$message_id,
            ]);					
}else{
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy` WHERE `id` = '$from_id'"));
$orderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen` WHERE `id` = '$from_id'"));
$orderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike` WHERE `id` = '$from_id'"));
$orderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel` WHERE `id` = '$from_id'"));
if( $user['language'] == "en" ){
$bazdid = $setting['seen'] * 1000;
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"👤 My Account You Are A Robot $botname :

🆔 ID : $from_id
🗣 Name : $first_name

💰 Your account balance : {$user['coin']} Toman
👥 Number of subsets : {$user['member']} person

👁 Number of visit orders : $orderseen
👍🏻 Number of likes orders : $orderlike
🎯 Number of automatic visit channels : $orderchannel
🛍 Number of purchases : $allbuy 

⬆️ You can invite your friends to the robot with your own link for each person {$setting['member']} Get a balance of Tomans
ℹ️ The cost per 1000 visits is equal to $bazdid Is USD, the cost of each number of likes (votes) is equal to {$setting['like']} Is Tomans",
'reply_to_message_id'=>$message_id,
            ]);					
}else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '🆘 پشتیبانی و قوانین' or $text == '🆘 Support and rules'){
if( $user['language'] == "fa" ){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔰 تیم پشتیبانی $botname با افتخار آماده پاسخگویی به شما عزیزان است:
$usernamesup

⚖️ کاربر گرامی، چنانچه شما از ربات $botname استفاده نمایید به منزله قبول قوانین زیر است:

👈 تنها مرجع رسمی افزایش موجودی ربات، بخش '➕ افزایش موجودی' است.
👈 خرید و فروش موجودی ربات توسط کاربران ممنوعیتی ندارد اما $botname هیچ گونه تعهدی در این رابطه ندارد.
👈 درصورتی که تراکنش مشکوکی مشاهده شود $botname این اختیار را دارد که از کاربر مربوطه مدارک موردنیاز را درخواست کند.
👈 در صورت استفاده نادرست از بخش های زیرمجموعه گیری و ارسال اکانت حساب شخص مسدود خواهد شد.",
'reply_to_message_id'=>$message_id,
            ]);	
}else{
if( $user['language'] == "en" ){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🔰 Support team $botname Proudly ready to respond to you dear ones:
$usernamesup

⚖️ Dear user, if you are a robot $botname Use constitutes acceptance of the following rules:

👈 The only official reference to increase robot inventory, section '➕ Buy coins' is.
👈 Buying and selling robot inventory by users is not prohibited, however $botname It has no obligation in this regard.
👈 If a suspicious transaction is observed $botname Has the right to request the required documents from the relevant user.
👈 In case of incorrect use of the sub-sections and sending the account, the person's account will be blocked.",
'reply_to_message_id'=>$message_id,
            ]);
}
else{
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$changelan,
            ]); 
}}}
elseif($text == '💸 انتقال سکه' ){
	if($user['coin'] > 100){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💸 در این بخش میتوانید سکه های خودتان را به سایر کابران $botname انتقال دهید.
موجودی شما: {$user['coin']} سکه

تعداد سکه موردنظر برای انتقال را وارد کنید",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back,
            ]);
$connect->query("UPDATE `user` SET `step` = 'sendid' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ موجودی حساب شما کافی نیست , برای انتقال باید حداقل 100 تومان موجودی داشته باشید .',
    'reply_to_message_id'=>$message_id,
            ]);
}
elseif($text == '💸 Coin transfer' ){
	if($user['coin'] > 100){
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"💸 In this section, you can give your coins to other users $botname Transfer.
Your inventory: {$user['coin']} Coin

Enter the number of coins you want to transfer",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen,
            ]);
$connect->query("UPDATE `user` SET `step` = 'sendiden' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Your account balance is not enough, you must have at least 100 Tomans to transfer.',
    'reply_to_message_id'=>$message_id,
            ]);
}
elseif($text == '🛒 تراکنش ها'){
$order = mysqli_query($connect,"SELECT * FROM `buy` WHERE `id` = '$from_id' ORDER BY `key` DESC LIMIT 10");
if(mysqli_num_rows($order) > 0){
while($row = mysqli_fetch_assoc($order))
$result = $result."🆔 شناسه خرید : {$row['key']}\n💳 مبلغ : {$row['amount']} تومان\n📅 زمان : {$row['time']}\n━ ━ ━\n";
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"🛍 لیست ده خرید اخیر شما , این لیست تنها جهت اطلاع شماست و کاردبرد دیگری ندارد
	
$result",
    'reply_to_message_id'=>$message_id,
     ]);
}else
 	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❌ شما تاکنون خریدی در ربات انجام نداده اید
👇🏻 برای شروع کافیست از دکمه "➕ افزایش موجودی" استفاده نمایید و مراحل را ادامه دهید .',
    'reply_to_message_id'=>$message_id,
     ]);
}
//===========================// data //===========================
elseif($data == 'join'){
if(bot('getChatMember',['chat_id'=>"@$channel",'user_id'=>$fromid])->result->status != 'left'){
	bot('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"☑️ عضویت شما در کانال تایید شد
$start",
'reply_to_message_id'=>$messageid,
     'reply_markup'=>$home
    		]);
}else{
       bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => "❌ هنوز داخل کانال « @$channel » عضو نیستی",
            'show_alert' =>true
        ]);
}
}	
elseif($data == 'badbutton'){
      bot('answercallbackquery', [
            'callback_query_id' =>$callback_query_id,
            'text' => '❗️ خطا ، این دکمه برای انجام سفارش لایک قابل انتخاب نیست',
            'show_alert' =>true
        ]);
}
//===========================// step //===========================
elseif ($user['step'] == 'seenamount') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  $limit = ($text > $result)?"💡 تمامی سفارشها تا سقف $result بازدید با توجه به سرعت انتخابی شما تکمیل خواهند شد و پس از آن بدون در نظر گرفتن سرعت تکمیل میشوند .":null;  
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ سرعت انجام سفارش را لطفا تنظیم نمایید 👇🏻
❗️ جهت تغییر سرعت و زمان شروع سفارش از دکمه تنظیم سرعت میتوانید استفاده نمایید .

• سریع : هر 5 دقیقه 1000 بازدید
• متوسط : هر 5 دقیقه 500  بازدید
• آهسته : هر 5 دقیقه 100 بازدید

$limit",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speed
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenspeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، میزان بازدید وارد شده از موجودی شما بیشتر است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}else
	
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);
}
elseif ($user['step'] == 'seenamounten') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  $limit = ($text > $result)?"💡 All orders up to the ceiling $result The visits will be completed according to the speed of your choice and then will be completed regardless of the speed.":null;  
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ Please adjust the order speed 👇🏻
❗️ You can use the speed adjustment button to change the speed and start time of the order .

• Fast: 1000 hits every 5 minutes
• Average: 500 views every 5 minutes
• Slow: 100 hits every 5 minutes

$limit",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speeden
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenspeeden' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, the number of hits received from your inventory

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);				
}else
	
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your message has an incorrect input number

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);
}
elseif ($user['step'] == 'seenspeed') {
$speedpanel = ['حداکثر سرعت','تنظیم سرعت','سریع','متوسط','آهسته'];
if(in_array($text , $speedpanel)){
if($text == 'تنظیم سرعت'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ افزایش بازدید بعد از چند دقیقه شروع شود
❗️ مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeed'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید
	
⚡️ سرعت تکمیل : $text
⏱ زمان شروع سفارش : فوری
👁‍🗨 تعداد بازدید درخواستی : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
	]);		
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("UPDATE `user` SET `step` = 'seenpost' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speed
            ]);				
}
elseif ($user['step'] == 'seenspeeden') {
$speedpanel = ['Maximum speed','Speed ​​adjustment','Fast','medium','Slow'];
if(in_array($text , $speedpanel)){
if($text == 'Speed ​​adjustment'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ The increase in traffic starts after a few minutes
❗️ Enter the allowable value as a number between 1 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeeden'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ Forward the desired post from the channel to the robot to increase traffic
	
⚡️ Completion speed : $text
⏱ Order start time: Immediate
👁‍🗨 Number of visits requested : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
	]);		
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("UPDATE `user` SET `step` = 'seenposten' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input
⏱ Please select the speed of completing your order using the buttons below 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speed
            ]);				
}
elseif ($user['step'] == 'configspeed') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
❗️ مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedtime' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ افزایش بازدید بعد از چند دقیقه شروع شود
👇🏻 مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeeden') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ Send visits every few minutes
❗️ Enter the allowable value as a number between 5 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedtimeen' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ The increase in traffic starts after a few minutes
👇🏻 Enter the allowable value as a number between 1 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
/*
@Sourrce_Kade
*/
elseif ($user['step'] == 'configspeedtime') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ چه مقدار بازدید در هر $text دقیقه ارسال شود
❗️ مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedseen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
👇🏻 مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeedtimeen') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ How many hits per $text Send minutes
❗️ Allow the amount to be between 10 and $explode[0] Enter a visit 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedseenen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ Send visits every few minutes
مجاز Enter the allowable value as a number between 5 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'configspeedseen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[0]){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید(درصورت نیاز میتوانید لینک پست موردنظر را ارسال کنید)
	
⚡️ سرعت تکمیل : هر $explode[2] دقیقه $text بازدید
⏱ زمان شروع سفارش : بعد از $explode[1] دقیقه
👁‍🗨 تعداد بازدید درخواستی : $explode[0]",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenpost' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ چه مقدار بازدید در هر $explode[2] دقیقه ارسال شود
👇🏻 مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeedseenen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[0]){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ Forward the desired post to the robot from the channel to increase traffic (if necessary, you can send the desired post link)
	
⚡️ Completion speed: any $explode[2] Minutes $text Visit
⏱ Order start time: after $explode[1] Minutes
👁‍🗨 Number of visits requested : $explode[0]",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenpost' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your request has incorrect input

⏱ How many hits per $explode[2] Send minutes
👇🏻 Allow the amount to be between 10 and $explode[0] Enter a visit",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
//===========================
elseif ($user['step'] == 'seentamount') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ سرعت انجام سفارش را لطفا تنظیم نمایید 👇🏻
❗️ جهت تغییر سرعت و زمان شروع سفارش از دکمه تنظیم سرعت میتوانید استفاده نمایید .

• سریع : هر 5 دقیقه 1000 بازدید
• متوسط : هر 5 دقیقه 500  بازدید
• آهسته : هر 5 دقیقه 100 بازدید",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speed
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seentspeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، میزان بازدید وارد شده از موجودی شما بیشتر است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);
}
elseif ($user['step'] == 'seentamounten') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ Please adjust the order speed 👇🏻
❗️ You can use the speed adjustment button to change the speed and start time of the order.

• Fast: 1000 views every 5 minutes
• Average: 500 views every 5 minutes
• Slow: 100 hits every 5 minutes",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speeden
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seentspeeden' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, the number of hits received from your inventory

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your message has an incorrect input number

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);
}
elseif ($user['step'] == 'seentspeed') {
$speedpanel = ['حداکثر سرعت','تنظیم سرعت','سریع','متوسط','آهسته'];
if(in_array($text , $speedpanel)){
if($text == 'تنظیم سرعت'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ افزایش بازدید بعد از چند دقیقه شروع شود
❗️ مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeed'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید (درصورت نیاز میتوانید لینک پست موردنظر را ارسال کنید)
	
⚡️ سرعت تکمیل : $text
⏱ زمان شروع سفارش : فوری
👁‍🗨 تعداد بازدید درخواستی : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
	]);		
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("UPDATE `user` SET `step` = 'seentpost' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speed
            ]);				
}
elseif ($user['step'] == 'seentspeeden') {
$speedpanel = ['Maximum speed','Speed ​​adjustment','Fast','medium','Slow'];
if(in_array($text , $speedpanel)){
if($text == 'Speed ​​adjustment'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ The increase in traffic starts after a few minutes
❗️ Enter the allowable value as a number between 1 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeeden'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ Forward the desired post to the robot from the channel to increase traffic (if necessary, you can send the desired post link)
	
⚡️ Completion speed : $text
⏱ Order start time: Immediate
👁‍🗨 Number of visits requested : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
	]);		
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("UPDATE `user` SET `step` = 'seentpost' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input
⏱ Please select the speed of completing your order using the buttons below 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speeden
            ]);				
}
elseif ($user['step'] == 'configtspeed') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
❗️ مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configtspeedtime' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ افزایش بازدید بعد از چند دقیقه شروع شود
👇🏻 مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configtspeeden') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ Send visits every few minutes
❗️ Enter the allowable value as a number between 5 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configtspeedtimeen' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ The increase in traffic starts after a few minutes
👇🏻 Enter the allowable value as a number between 1 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'configtspeedtime') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ چه مقدار بازدید در هر $text دقیقه ارسال شود
❗️ مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configtspeedseen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
👇🏻 مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configtspeedtimeen') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ How many hits per $text Send minutes
❗️ Allow the amount to be between 10 and $explode[0] Enter a visit 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configtspeedseenen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ Send visits every few minutes
👇🏻 Enter the allowable value as a number between 5 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'configtspeedseen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[0]){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ پست مورد نظر را از کانال جهت افزایش بازدید , به ربات فوروارد نمایید(درصورت نیاز میتوانید لینک پست موردنظر را ارسال کنید)
	
⚡️ سرعت تکمیل : هر $explode[2] دقیقه $text بازدید
⏱ زمان شروع سفارش : بعد از $explode[1] دقیقه
👁‍🗨 تعداد بازدید درخواستی : $explode[0]",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seentpost' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ چه مقدار بازدید در هر $explode[2] دقیقه ارسال شود
👇🏻 مقدار مجاز را به صورت عدد بین  10 الی $explode[0] بازدید وارد کنید",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configtspeedseenen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[0]){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ Forward the desired post to the robot from the channel to increase traffic (if necessary, you can send the desired post link)
	
⚡️ Completion speed: any $explode[2] Minutes $text Visit
⏱ Order start time: after $explode[1] Minutes
👁‍🗨 Number of visits requested : $explode[0]",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seentposten' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your request has incorrect input

⏱ How many hits per $explode[2] Send minutes
👇🏻 Allow the amount to be between 10 and $explode[0] Enter a visit",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'likeamount') {
$max = floor($user['coin'] / $setting['like']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 1 and $text <= $result){
if($user['coin'] >= $text * $setting['like']){	
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ سرعت انجام سفارش را لطفا تنظیم نمایید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speedlike
            ]);	
$connect->query("UPDATE `user` SET `step` = 'likespeed' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، میزان لایک وارد شده از موجودی شما بیشتر است

👇🏻 تعداد لایک (رأی) مورد نظر را به صورت عددی بین 10 الی $ma وارد کنید
👍🏻 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max لایک را سفارش دهید",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد لایک (رأی) مورد نظر را به صورت عددی بین 1 الی $result وارد کنید
👍🏻 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max لایک را سفارش دهید",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);
}
elseif ($user['step'] == 'likeamounten') {
$max = floor($user['coin'] / $setting['like']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 10 and $text <= $result){
if($user['coin'] >= $text * $setting['like']){	
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ Please adjust the order speed 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speedlikeen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'likespeeden' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ The error is the amount of likes entered from your inventory

👇🏻 The desired number of likes (votes) numerically between 10 to $ma enter
👍🏻 Your account balance {$user['coin']} Rs and you can max $max Order Like",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your message has an incorrect input number

👇🏻 The desired number of likes (votes) numerically between 1 to $result enter
👍🏻 Your account balance {$user['coin']} Rs and you can max $max Order Like",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);
}
elseif ($user['step'] == 'likespeed') {
$speedpanel = ['حداکثر سرعت','هر 2 دقیقه 1 لایک','هر 5 دقیقه 1 لایک','هر 15 دقیقه 1 لایک','هر 30 دقیقه 1 لایک'];
if(in_array($text , $speedpanel)){
  $amount = $user['data'] * $setting['like'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید
	
⚡️ سرعت تکمیل : $text
💰 هزینه سفارش : $amount تومان
👍🏻 تعداد درخواست لایک : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
	]);		
$keys = [$speedpanel[0]=>'1',$speedpanel[1]=>'2',$speedpanel[2]=>'5',$speedpanel[3]=>'15',$speedpanel[4]=>'30'];
$connect->query("UPDATE `user` SET `step` = 'likebutton' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speedlike
            ]);				
}
elseif ($user['step'] == 'likespeeden') {
$speedpanel = ['Maximum speed','1 like every 2 minutes','1 like every 5 minutes','1 like every 15 minutes','1 like every 30 minutes'];
if(in_array($text , $speedpanel)){
  $amount = $user['data'] * $setting['like'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⬅️ Forward the desired post (poll) to the bot to increase the likes (votes) from a public channel
	
⚡️ Completion speed : $text
💰 Order cost : $amount Toman
👍🏻 Number of likes : {$user['data']}",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
	]);		
$keys = [$speedpanel[0]=>'1',$speedpanel[1]=>'2',$speedpanel[2]=>'5',$speedpanel[3]=>'15',$speedpanel[4]=>'30'];
$connect->query("UPDATE `user` SET `step` = 'likebuttonen' , `data` = CONCAT(`data`,'^{$keys[$text]}') WHERE `id` = '$from_id' LIMIT 1");	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input
⏱ Please select the speed of completing your order using the buttons below 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speedlikeen
            ]);				
}


elseif ($user['step'] == 'likebutton') {
if($message->poll == true) { 
if($message->poll->is_closed == false) { $i = 0;
  foreach ($message->poll->options as $k => $v) {
    $substrtext = (mb_strlen($v->text) <= 27)?$v->text:mb_substr($v->text,0,27).'...';	  
    $key[] = [['text'=>$v->text,'callback_data'=>"bu_{$i}_0_{$substrtext}"]];
	$i ++;
  }
    bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'👇🏻 لطفا گزینه مورد نظر را که مایلید برای آن لایک سفارش دهید را انتخاب کنید
• انجام لایک و رأی برای پست هایی که نیاز به جوین شدن در کانال داشته باشد امکان پذیر نیست .',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
    'inline_keyboard'=>$key
        ])
            ]);
  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",   
  'from_chat_id'=>$from_id,
  'message_id'=>$message_id,
  ])->result->message_id;
  $connect->query("UPDATE `user` SET `data` = CONCAT(`data`,'^$channelorder^$id') WHERE `id` = '$from_id' LIMIT 1");
} else
	  bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'️❗️ خطا ، نظر سنجی ارسال شده به اتمام رسیده است
⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$back
            ]);
} else {
  $forward_from_chat_username = $message->forward_from_chat->username;
  if($forward_from_chat_username == true){
  $key = file_get_contents("$webapi/button.php?channel=@$forward_from_chat_username&post={$message->forward_from_message_id}");
  if($key == '0')
  bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'️❗️ خطا ، پست ارسال شده فاقد دکمه برای انجام سفارش است
⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$back
            ]);
else {
	bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'👇🏻 لطفا گزینه مورد نظر را که مایلید برای آن لایک سفارش دهید را انتخاب کنید
• انجام لایک و رأی برای پست هایی که نیاز به جوین شدن در کانال داشته باشد امکان پذیر نیست .',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$key
            ]);
	$connect->query("UPDATE `user` SET `data` = CONCAT(`data`,'^$forward_from_chat_username^{$message->forward_from_message_id}') WHERE `id` = '$from_id' LIMIT 1");
}			
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ پست ارسال شده معتبر نیست
⬅️ پست (نظر سنجی) مورد نظر را جهت افزایش لایک (رأی) از یک کانال عمومی به ربات فوروارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
}




//==================== En





elseif ($user['step'] == 'likebuttonen') {
if($message->poll == true) { 
if($message->poll->is_closed == false) { $i = 0;
  foreach ($message->poll->options as $k => $v) {
    $substrtext = (mb_strlen($v->text) <= 27)?$v->text:mb_substr($v->text,0,27).'...';	  
    $key[] = [['text'=>$v->text,'callback_data'=>"bu_{$i}_0_{$substrtext}"]];
	$i ++;
  }
    bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'👇🏻 Please select the desired option for which you like to order
• It is not possible to like and vote for posts that require joining the channel .',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>json_encode([
    'inline_keyboard'=>$key
        ])
            ]);
  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",   
  'from_chat_id'=>$from_id,
  'message_id'=>$message_id,
  ])->result->message_id;
  $connect->query("UPDATE `user` SET `data` = CONCAT(`data`,'^$channelorder^$id') WHERE `id` = '$from_id' LIMIT 1");
} else
	  bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'️❗️ Error, polls posted completed
⬅️ Forward the desired post (poll) to the bot to increase the likes (votes) from a public channel',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$backen
            ]);
} else {
  $forward_from_chat_username = $message->forward_from_chat->username;
  if($forward_from_chat_username == true){
  $key = file_get_contents("$webapi/button.php?channel=@$forward_from_chat_username&post={$message->forward_from_message_id}");
  if($key == '0')
  bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'️❗️ Error, the post sent does not have a button to place an order
⬅️ Forward the desired post (poll) to the bot to increase the likes (votes) from a public channel',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$backen
            ]);
else {
	bot('sendmessage',[
	'chat_id'=>$chat_id,
    'text'=>'👇🏻 Please select the desired option for which you like to order
• It is not possible to like and vote for posts that require joining the channel .',
    'reply_to_message_id'=>$message_id,
	'reply_markup'=>$key
            ]);
	$connect->query("UPDATE `user` SET `data` = CONCAT(`data`,'^$forward_from_chat_username^{$message->forward_from_message_id}') WHERE `id` = '$from_id' LIMIT 1");
}			
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ The post sent is not valid
⬅️ Forward the desired post (poll) to the bot to increase the likes (votes) from a public channel',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
}
elseif ($user['step'] == 'setchannel') {
   $forward_from_chat_id = $message->forward_from_chat->id;
if($forward_from_chat_id == true){
$getChatMember = bot('getChatMember',['chat_id'=>$forward_from_chat_id,'user_id'=>$botid])->result;
$getchat = bot('getchat',['chat_id'=>$forward_from_chat_id])->result;
if($getchat->type == 'channel' and $getChatMember->status != 'left'){
if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `channel` WHERE `channel` = '$forward_from_chat_id' limit 1")) <= 0)	{
$max = floor($user['coin'] / $setting['seen']);
$meghdarbazdid = $setting['seen'] * 1000;
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ کانال شما با موفقیت ثبت شد .

👁‍ تعداد بازدید دلخواه برای پستهای جدید را به صورت عدد بین 100 الی $result وارد نمایید 👇🏻

❗️ موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .
• هزینه هر 1000 بازدید برابر با $meghdarbazdid تومان است",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'amountchannel' , `data` = '$forward_from_chat_id' WHERE `id` = '$from_id' LIMIT 1");		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"ک❗️ خطا ، قبلا بازدید خودکار برای این کانال را ثبت کردید
👈🏻 برای حذف کانال کافیست از دکمه '📢 کانال های ثبت شده' استفاده نمایید",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'📢 کانال های ثبت شده']],
		[['text'=>'انصراف']],
		],
        'resize_keyboard'=>true,
       		])
            ]);	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، ربات در کانال شما ادمین نیست

✅ برای شروع ثبت بازدید خودکار , لطفا ربات @$usernamebot را در کانالتان ادمین کنید سپس یک پست از کانال را به ربات فوروارد نمایید
<a href='$web/help.php'>👮🏻 آموزش نحوه ادمین کردن ربات</a>",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، پست ارسال شده متعبر نیست
👇🏻 پستی که ارسال کرده اید، فوروارد نشده بود، برای ثبت بازدید خودکار حتما باید یک پست از کانال را فوروارد کنید .',
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);		
}
elseif ($user['step'] == 'setchannelen') {
   $forward_from_chat_id = $message->forward_from_chat->id;
if($forward_from_chat_id == true){
$getChatMember = bot('getChatMember',['chat_id'=>$forward_from_chat_id,'user_id'=>$botid])->result;
$getchat = bot('getchat',['chat_id'=>$forward_from_chat_id])->result;
if($getchat->type == 'channel' and $getChatMember->status != 'left'){
if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `channel` WHERE `channel` = '$forward_from_chat_id' limit 1")) <= 0)	{
$max = floor($user['coin'] / $setting['seen']);
$bazdid = $setting['seen'] * 1000;
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ Your channel has been successfully registered.

👁‍ The desired number of hits for new posts as a number between 100 to $result Enter 👇🏻

❗️ Your account balance {$user['coin']} Rs and you can max $max Order a visit.
• The cost per 1000 visits is equal to $bazdid Is Tomans",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'amountchannelen' , `data` = '$forward_from_chat_id' WHERE `id` = '$from_id' LIMIT 1");		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, you have already registered an automatic visit for this channel
👈🏻 To delete a channel, just use the '📢 Registered Channels' button",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>json_encode([
        'keyboard'=>[
		[['text'=>'📢 Registered Channels']],
		[['text'=>'Cancel']],
		],
        'resize_keyboard'=>true,
       		])
            ]);	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, the bot is not an admin on your channel

✅ To start auto-logging, please see Robot @$usernamebot Admin in your channel, then forward a post from the channel to the robot
<a href='$web/help.php'>👮🏻 Learn how to administer a robot</a>",
'parse_mode'=>'HTML',
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);		
}else
	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, post sent is not valid
👇🏻 The post you submitted was not forwarded, you must forward a post from the channel to register an automatic visit .',
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);		
}
elseif ($user['step'] == 'amountchannel') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  $limit = ($text > $result)?"💡 تمامی سفارشها تا سقف $result بازدید با توجه به سرعت انتخابی شما تکمیل خواهند شد و پس از آن بدون در نظر گرفتن سرعت تکمیل میشوند .":null;  
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ سرعت انجام سفارش را لطفا تنظیم نمایید 👇🏻
❗️ جهت تغییر سرعت و زمان شروع سفارش از دکمه تنظیم سرعت میتوانید استفاده نمایید .

• سریع : هر 5 دقیقه 1000 بازدید
• متوسط : هر 5 دقیقه 500  بازدید
• آهسته : هر 5 دقیقه 100 بازدید

$limit",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speed
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenspeedch' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، میزان بازدید وارد شده از موجودی شما بیشتر است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است

👇🏻 تعداد بازدید دلخواه را به صورت عدد بین 100 الی $result وارد نمایید
👁 موجودی حساب شما {$user['coin']} تومان هست و میتوانید حداکثر $max بازدید را سفارش دهید .",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);
}
elseif ($user['step'] == 'amountchannelen') {
$max = floor($user['coin'] / $setting['seen']);
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$maxorder = $result->maxorder;
if(is_numeric($text) and $text >= 100 and $text <= $result){
if($user['coin'] >= $text * $setting['seen']){	
  $limit = ($text > $result)?"💡 All orders up to the ceiling $result The visits will be completed according to the speed of your choice and then will be completed regardless of the speed.":null;  
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ Please adjust the order speed 👇🏻
❗️ You can use the speed adjustment button to change the speed and start time of the order.

• Fast: 1000 hits every 5 minutes
• Average: 500 views every 5 minutes
• Slow: 100 hits every 5 minutes

$limit",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$speeden
            ]);	
$connect->query("UPDATE `user` SET `step` = 'seenspeedchen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");	
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, the number of hits received from your inventory

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);				
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your message has an incorrect input number

👇🏻 The desired number of visits as a number between 100 to $result Enter
👁 Your account balance {$user['coin']} Rs and you can max $max Order a visit.",
'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);
}
elseif ($user['step'] == 'seenspeedch') {
$speedpanel = ['حداکثر سرعت','تنظیم سرعت','سریع','متوسط','آهسته'];
if(in_array($text , $speedpanel)){
if($text == 'تنظیم سرعت'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ افزایش بازدید بعد از چند دقیقه شروع شود
❗️ مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedch'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  $explode = explode('^',$user['data']);
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $setting['seen'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : فوری و $text
💰 هزینه سفارش هر پست : $amount تومان
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
❌ برای لغو سفارش /del_".abs($explode[0])."",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
	]);		
	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : فوری و $text
💰 هزینه سفارش هر پست : $amount تومان
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("INSERT INTO `channel` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '{$keys[$text]}' , '$explode[1]')");		
$connect->query("UPDATE `user` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است
⏱ لطفا سرعت تکمیل سفارش خود را با استفاده از دکمه های زیر انتخاب نمایید 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speed
            ]);				
}
elseif ($user['step'] == 'seenspeedchen') {
$speedpanel = ['Maximum speed','Speed ​​adjustment','Fast','medium','Slow'];
if(in_array($text , $speedpanel)){
if($text == 'Speed ​​adjustment'){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ The increase in traffic starts after a few minutes
❗️ Enter the allowable value as a number between 1 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedchen'  WHERE `id` = '$from_id' LIMIT 1");		
}else{
  $explode = explode('^',$user['data']);
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $setting['seen'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"☑️ Order auto-visits for channels $title it is registered .

⚡️ Order speed: instant and $text
💰 The cost of ordering each post : $amount Toman
👁‍🗨 Requested views for each post : $explode[1]
❌ To cancel the order /del_".abs($explode[0])."",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$homeen
	]);		
$keys = [$speedpanel[0]=>'0^0^0',$speedpanel[2]=>'0^5^1000',$speedpanel[3]=>'0^5^500',$speedpanel[4]=>'0^5^100'];
$connect->query("INSERT INTO `channel` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '{$keys[$text]}' , '$explode[1]')");		
$connect->query("UPDATE `user` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");	
}
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input
⏱ Please select the speed of completing your order using the buttons below 👇🏻',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$speeden
            ]);				
}
elseif ($user['step'] == 'configspeedch') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
❗️ مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedtimech' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ افزایش بازدید بعد از چند دقیقه شروع شود
👇🏻 مقدار مجاز را به صورت عدد بین  1 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeedchen') {
if(is_numeric($text) and $text >= 1 and $text <= 1440){
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'⏱ Send visits every few minutes
❗️ Enter the allowable value as a number between 5 and 1440 minutes 👇🏻',
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedtimechen' , `data` = CONCAT(`data`,'^$text')  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ The increase in traffic starts after a few minutes
👇🏻 Enter the allowable value as a number between 1 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'configspeedtimech') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ چه مقدار بازدید در هر $text دقیقه ارسال شود
❗️ مقدار مجاز را به صورت عدد بین  10 الی $explode[1] بازدید وارد کنید 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$back
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedseench' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ ارسال بازدید هر چند دقیقه یک بار انجام شود
👇🏻 مقدار مجاز را به صورت عدد بین  5 الی 1440 دقیقه وارد کنید',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeedtimechen') {
if(is_numeric($text) and $text >= 5 and $text <= 1440){
  $explode = explode('^',$user['data']);
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"⏱ How many hits per $text Send minutes
❗️ Allow the amount to be between 10 and 10 $explode[1] Enter a visit 👇🏻",
    'reply_to_message_id'=>$message_id,
     'reply_markup'=>$backen
            ]);	
$connect->query("UPDATE `user` SET `step` = 'configspeedseenchen' , `data` = CONCAT(`data`,'^$text') WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>'❗️ Error, your request has incorrect input

⏱ Send visits every few minutes
👇🏻 Enter the allowable value as a number between 5 and 1440 minutes',
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif ($user['step'] == 'configspeedseench') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[1]){
  $start = ($explode[2] == 0)?'فوری':"بعد از $explode[2] دقیقه";
  $speed = ($explode[3] == 0)?'حداکثر سرعت':"هر $explode[3] دقیقه $text بازدید";
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $setting['seen'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : $start و $speed
💰 هزینه سفارش هر پست : $amount تومان
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
❌ برای لغو سفارش /del_".abs($explode[0])."",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$home
	]);		
		bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید خودکار برای کانال $title ثبت شد .

⚡️ سرعت انجام سفارش : $start و $speed
💰 هزینه سفارش هر پست : $amount تومان
👁‍🗨 تعداد بازدید درخواستی برای هر پست : $explode[1]
	
	[$chat_id](tg://user?id=$chat_id)",
	'parse_mode'=>'Markdown',
                ]);
$connect->query("INSERT INTO `channel` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '$explode[2]^$explode[3]^$text' , '$explode[1]')");		
$connect->query("UPDATE `user` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ خطا ، درخواست شما دارای ورودی نادرست است

⏱ چه مقدار بازدید در هر $explode[3] دقیقه ارسال شود
👇🏻 مقدار مجاز را به صورت عدد بین  10 الی $explode[1] بازدید وارد کنید",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$back
            ]);				
}
elseif ($user['step'] == 'configspeedseenchen') {
$explode = explode('^',$user['data']);
if(is_numeric($text) and $text >= 100 and $text <= $explode[1]){
  $start = ($explode[2] == 0)?'instantaneous':"after $explode[2] Minutes";
  $speed = ($explode[3] == 0)?'Maximum speed':"Any $explode[3] Minutes $text Visit";
  $title = bot('getchat',['chat_id'=>$explode[0]])->result->title;
  $amount = $explode[1] * $setting['seen'];
  bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"☑️ Order auto-visits for channels $title it is registered .

⚡️ Order speed : $start و $speed
💰 The cost of ordering each post : $amount Toman
👁‍🗨 Requested views for each post : $explode[1]
❌ To cancel the order /del_".abs($explode[0])."",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$homeen
	]);		
$connect->query("INSERT INTO `channel` (`channel` , `id` , `speed` , `view`) VALUES ('$explode[0]' , '$from_id' , '$explode[2]^$explode[3]^$text' , '$explode[1]')");		
$connect->query("UPDATE `user` SET `step` = 'none'  WHERE `id` = '$from_id' LIMIT 1");		
}else
bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"❗️ Error, your request has incorrect inpu

⏱ How many hits per $explode[3] Send minutes
👇🏻 Allow the amount to be between 10 and $explode[1] Enter a visit",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>$backen
            ]);				
}
elseif($user['step'] == 'pay' && $tc == 'private'){
if($text >= $setting['hadaghalkharid'] and $text <= $setting['hadaksarkharid']){
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>'⏳ در حال ساخت فاکتور پرداخت ...',
			'reply_markup'=>$home
	        ]);	
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"✅ فاکتور افزایش موجودی با مبلغ $text تومان با موفقیت برای شما ساخته شد
   
☑️ تمامی پرداخت ها به صورت اتوماتیک بوده و پس از تراکنش موفق مبلغ آن به موجودی حساب شما در ربات افزوده خواهد شد .

👇🏻 پرای پرداخت کافیست از دکمه زیر استفاده کنید",
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text' => "💳 پرداخت $text تومان", 'url' => pay($text)]],
              ]
              ])
	       ]);	
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}else
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"❗️ خطا ، پیام شما دارای عدد ورودی نادرست است
👇🏻 برای افزایش موجودی حساب مبلغ موردنظر خود را به تومان وارد نمایید

💡 توجه کنید که مبلغ را به عدد وارد کنید و حداقل میتوانید {$setting['hadaghalkharid']} و حداکثر {$setting['hadaksarkharid']} تومان حساب خود را شارژ کنید",
			'reply_to_message_id'=>$message_id,
	              ]);	
}
elseif($user['step'] == 'sendid'){
if(is_numeric($text) and $user['coin'] >= $text and $text > 100 ){
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"🛑 توجه: عملیات انتقال سکه غیرقابل بازگشت است!

👈 درصورتی که درخواست انتقال $text سکه مورد تاییدتان است، شناسه کاربری مقصد را ارسال کنید.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
	]);	
 $connect->query("UPDATE `user` SET `step` = 'sendcoin' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"❗️ خطا ، مبلغ وارد شده نادرست یا از موجودی حساب شما بیشتر است
			
👇🏻 مبلغ مورد نظر جهت انتقال را به تومان وارد نمایید
💰 موجودی حساب شما {$user['coin']} تومان است",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$back
	]);	
}
elseif($user['step'] == 'sendiden'){
if(is_numeric($text) and $user['coin'] >= $text and $text > 100 ){
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"🛑 Note: Coin transfer operations are non-refundable!

👈 In case of transfer request $text The coin is approved, send the destination user ID.",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen
	]);	
 $connect->query("UPDATE `user` SET `step` = 'sendcoinen' , `data` = '$text' WHERE `id` = '$from_id' LIMIT 1");
}else
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"❗️ Error, amount entered incorrectly or more than your account balance
			
👇🏻 Enter the desired amount for transfer in Tomans
💰 Your account balance {$user['coin']} Is Tomans",
'reply_to_message_id'=>$message_id,
'reply_markup'=>$backen
	]);	
}
elseif($user['step'] == 'sup'){
	    bot('sendmessage',[       
		'chat_id'=>$chat_id,
		'text'=>'✅ پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید',
        'reply_to_message_id'=>$message_id,
        'reply_markup'=>$back
	       ]);	
        bot('ForwardMessage',[
        'chat_id'=>$admin[0],
        'from_chat_id'=>$chat_id,
        'message_id'=>$message_id
           ]);
		   	    bot('sendmessage',[       
		'chat_id'=>$admin[0],
		'text'=>"👆🏼 پیام بالا توسط کاربر $from_id ارسال شده است",
		'parse_mode'=>"MarkDown",
		'reply_markup' => json_encode([
		'inline_keyboard' => [
		[
		['text' => " 💬 ارسال پاسخ به کاربر", 'callback_data' => "sendmessage-$chat_id"]
                            
		],
                       
		],
		'resize_keyboard' => true
		]),
		]);	
		}
elseif(strpos($data,"sendmessage-") !== false){
 $ex = explode("-",$data)[1];
 bot('sendmessage',[       
   'chat_id'=>$chatid,
   'text'=>"پیام خود را ارسال کنید.",
   		'parse_mode'=>"MarkDown",
		'reply_markup' => json_encode([
		'inline_keyboard' => [
		[
		['text' => "💬", 'callback_data' => "jjj"]
                            
		],
                       
		],
		'resize_keyboard' => true
		]),
		]);	
		$connect->query("UPDATE user SET step = 'smposh,$ex' WHERE id = '$fromid' LIMIT 1");
		}
elseif(strpos($user["step"], "smposh,") !== false && $text !="انصراف" && $text !="/panel" && $text !="/start"){
 $ex = explode(",",$user["step"])[1];
 bot('sendmessage',[       
   'chat_id'=>$ex,
   'text'=>"پیام پشتیبانی : $text",
 ]); 
 bot('sendmessage',[       
   'chat_id'=>$chat_id,
   'text'=>"ارسال شد",
 ]); 
 $connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");
}
//===========================// panel admin //===========================
elseif($text == '/panel' and $tc == 'private' and in_array($from_id,$admin)){
   bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"📍 ادمین عزیز به پنل مدریت ربات خوش امدید",
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"📍 آمار ربات"]],
	   [['text'=>"📍 اطلاعات کاربر"],['text'=>"📍 وبسرویس"]],
	   [['text'=>"📍 شارژ پنل"],['text'=>"📍 افزایش موجودی"]],
	   [['text'=>"📍 حذف مسدودیت"],['text'=>"📍 مسدود کردن"]],
       [['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
	   [['text'=>"📍 ربات روشن"],['text'=>"📍 ربات خاموش"]],
	   [['text'=>"📍 تنظیم مرچند آیدی"]],
	   [['text'=>"📍 تنظیم چنل شماره"],['text'=>"📍 تنظیم چنل خرید"]],
	   [['text'=>"📍 تنظیم چنل انتقالات"]],
	   [['text'=>"📍 تنظیم هدیه دعوت"],['text'=>"📍 تنظیم هدیه ورود"]],
	   [['text'=>"📍 تنظیم پورسانت خرید"]],
	   [['text'=>"📍 تنظیم قیمت لایک"],['text'=>"📍 تنظیم قیمت سین"]],
	   [['text'=>"📍 تنظیم قیمت ری اکشن"]],
	   [['text'=>"📍 حداکثر خرید"],['text'=>"📍 حداقل خرید"]],
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
}
elseif($text == 'برگشت 🔙' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"🚦 به منوی مدیریت بازگشتید",
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"📍 آمار ربات"]],
	   [['text'=>"📍 اطلاعات کاربر"],['text'=>"📍 وبسرویس"]],
	   [['text'=>"📍 شارژ پنل"],['text'=>"📍 افزایش موجودی"]],
	   [['text'=>"📍 حذف مسدودیت"],['text'=>"📍 مسدود کردن"]],
       [['text'=>"📍 ارسال به کاربران"],['text'=>"📍 فروارد به کاربران"]],
	   [['text'=>"📍 ربات روشن"],['text'=>"📍 ربات خاموش"]],
	   [['text'=>"📍 تنظیم مرچند آیدی"]],
	   [['text'=>"📍 تنظیم چنل شماره"],['text'=>"📍 تنظیم چنل خرید"]],
	   [['text'=>"📍 تنظیم چنل انتقالات"]],
	   [['text'=>"📍 تنظیم هدیه دعوت"],['text'=>"📍 تنظیم هدیه ورود"]],
	   [['text'=>"📍 تنظیم پورسانت خرید"]],
	   [['text'=>"📍 تنظیم قیمت لایک"],['text'=>"📍 تنظیم قیمت سین"]],
	   [['text'=>"📍 تنظیم قیمت ری اکشن"]],
	   [['text'=>"📍 حداکثر خرید"],['text'=>"📍 حداقل خرید"]],
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($text == '📍 تنظیم مرچند آیدی' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"📍 به بخش تنظیم مرچند ایدی خوش امدید
   
لطفا مرچند آیدی زرین پال را بفرستید :",
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setmerchendid' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setmerchendid' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ مرچند آیدی با موفقیت به مرچند آیدی زیر تغییر کرد :

$text",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `MerchantID` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم چنل شماره' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا آیدی عددی را ارسال کنید :

`نمونه : -33325125134`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setlognumber' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setlognumber' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `channelsabtnumber` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم چنل خرید' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا آیدی عددی را ارسال کنید :

`نمونه : -33325125134`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setlogbuy' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setlogbuy' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `channelkharid` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم چنل انتقالات' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا آیدی کانال را ارسال کنید :

`نمونه : telegram`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setlogenteghal' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setlogenteghal' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `channelenteghalat` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم هدیه دعوت' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 50`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setaddmember' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setaddmember' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `member` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم هدیه ورود' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 100`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setwelcomebot' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setwelcomebot' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `gift` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم پورسانت خرید' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 10`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setporsant' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setporsant' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `porsant` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم قیمت لایک' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 20`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setlikecoin' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setlikecoin' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `like` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم قیمت سین' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 0,1`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setseencoin' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setseencoin' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `seen` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 تنظیم قیمت ری اکشن' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 10`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'setreactioncoin' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'setreactioncoin' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `reaction` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 حداکثر خرید' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 500000`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'sethadaksar' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'sethadaksar' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `hadaksarkharid` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 حداقل خرید' and $tc == 'private' and in_array($from_id,$admin)){
    bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"به بخش $text خوش آمدید

لطفا مقدار مورد نظر را وارد کنید :

`نمونه : 10000`",
   'parse_mode' => 'Markdown',
   'reply_markup'=>json_encode([
   'keyboard'=>[
	   [['text'=>"انصراف"]],
            ],
      'resize_keyboard'=>true
      ])
    ]);
$connect->query("UPDATE `user` SET `step` = 'sethadaghal' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif($user['step'] == 'sethadaghal' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ با موفقیت به :

$text

تغییر کرد",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `setting` SET `hadaghalkharid` = '$text' LIMIT 1");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($text == '📍 آمار ربات' and $tc == 'private' and in_array($from_id,$admin)){
$alluser = mysqli_num_rows(mysqli_query($connect,"select `id` from `user`"));
$allorderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen`"));
$allorderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike`"));
$allorderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel`"));
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy`"));
$allblock = mysqli_num_rows(mysqli_query($connect,"select `id` from `block`"));
$result = curl("$webapi/?type=amount&apikey=$apikey");
$result = curl("$webapi/?apikey=$apikey&type=stats");
$result = $result->maxorder;
$tedadbazdid = $setting['seen'] * 1000;
		bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 آمار ربات $botname تا این لحظه : 
		
📍 تعداد کاربران : $alluser
📍 موجودی پنل : {$result->amount}

📍 تعداد خرید ها : $allbuy
📍 تعداد مسدود ها : $allblock

📍 شناسه وبسرویس : $apikey

📍 تعداد سفارشات بازدید : $allorderseen
📍 تعداد سفارشات لایک : $allorderlike
📍 تعداد کانال های ثبت شده : $allorderchannel

📍 سقف تکمیل سین : $result2
📍 سقف تکمیل لایک : $result2
📍 سقف تکمیل رائ : $result2

📍 قیمت هرکا سین در ربات : $tedadbazdid
📍 قیمت هر یک لایک در ربات : {$setting['like']}
📍 ادمین apikey وبسرویس : $adminapi

🔑 ربات مدیریت و دریافت کلید وبسرویس :
$webserviceid",
		]);
		}
		elseif($text == '📍 وبسرویس' and $tc == 'private' and in_array($from_id,$admin)){
$allorderseen = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderseen`"));
$allorderlike = mysqli_num_rows(mysqli_query($connect,"select `id` from `orderlike`"));
$allorderchannel = mysqli_num_rows(mysqli_query($connect,"select `id` from `channel`"));
$allbuy = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy`"));
$result = curl("$webapi/?type=amount&apikey=$apikey");
$tedadbazdid = $setting['seen'] * 1000;
		bot('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"🤖 آمار و اطلاعات وبسرویس
		
📍 موجودی پنل : {$result->amount}

📍 تعداد سفارشات بازدید : $allorderseen
📍 تعداد سفارشات لایک : $allorderlike
📍 تعداد کانال های ثبت شده : $allorderchannel

📍 تعداد خرید ها : $allbuy
📍 قیمت هرکا سین در ربات : $tedadbazdid
📍 قیمت هر یک لایک در ربات : {$setting['like']}
📍 ادمین apikey وبسرویس : $adminapi

📍 شناسه وبسرویس : $apikey

👇🏼 جهت شارژ وبسرویس از دکمه '📍 شارژ پنل' استفاده کنید

🔑 ربات مدیریت و دریافت کلید وبسرویس :
$webserviceid",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"📍 شارژ پنل"]],
[['text'=>"برگشت 🔙"]],
 ],
  'resize_keyboard'=>true
])
  ]);
}
		elseif ($text == '📍 حذف مسدودیت' and $tc == 'private' and in_array($from_id,$admin)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true
])
  ]);
$connect->query("UPDATE `user` SET `step` = 'unblock' WHERE `id` = '$from_id' LIMIT 1");
}
		elseif ($text == '📍 اطلاعات کاربر' and $tc == 'private' and in_array($from_id,$admin)){
 bot('sendmessage',[
 'chat_id'=>$chat_id,
 'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"برگشت 🔙"]]
 ],
  'resize_keyboard'=>true
])
  ]);
$connect->query("UPDATE `user` SET `step` = 'userinfos' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '📍 ارسال به کاربران' and $tc == 'private' and in_array($from_id,$admin)) {
         bot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
/*
@Sourrce_Kade
*/
$connect->query("UPDATE `user` SET `step` = 'sendtoall' WHERE `id` = '$from_id' LIMIT 1");
}
elseif ($text == '📍 ربات روشن' and in_array($from_id, $admin)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍 ربات روشن شد",
]);
unlink('bot');  
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
elseif ($text == '📍 ربات خاموش' and in_array($from_id, $admin)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📍 ربات خاموش شد",
]);
touch('bot');    
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
elseif ($text == '📍 فروارد به کاربران' and $tc == 'private' and in_array($from_id,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 لطفا پیام خود را فوروارد کنید [پیام فوروارد شده میتوانید از شخص یا کانال باشد]",
	     'reply_markup'=>json_encode([
         'keyboard'=>[
	         [['text'=>"برگشت 🔙"]]
                ],
           'resize_keyboard'=>true
              ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'fortoall' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 شارژ پنل' and $tc == 'private' and in_array($from_id,$admin)){
	$result = curl("$webapi/?type=amount&key=$apikey");
         bot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 موجودی پنل شما در حال حاظر {$result->amount} تومان است
📍 مبلغ مورد نظر را جهت شارژ مجدد وارد کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'charge' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 افزایش موجودی' and $tc == 'private' and in_array($from_id,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 لطفا در خط اول ایدی فرد و در خط دوم میزان موجودی را وارد کنید
📍 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید
267785153
20",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'sendadmin' WHERE `id` = '$from_id' LIMIT 1");		
}
elseif ($text == '📍 مسدود کردن' and $tc == 'private' and in_array($from_id,$admin)){
         bot('sendmessage',[
         'chat_id'=>$chat_id,
         'text'=>"📍 لطفا شناسه کاربری فرد را ارسال کنید",
	   'reply_markup'=>json_encode([
       'keyboard'=>[
	        [['text'=>"برگشت 🔙"]]
                 ],
          'resize_keyboard'=>true
            ])
          ]);
$connect->query("UPDATE `user` SET `step` = 'block' WHERE `id` = '$from_id' LIMIT 1");		
}
//===========================// admin step //===========================
elseif($user['step'] == 'userinfos' && $tc == 'private') {
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$text' LIMIT 1"));
$buy = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM buy WHERE id = '$text' LIMIT 1"));
$channel = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM channel WHERE id = '$text' LIMIT 1"));
$allbuys = mysqli_num_rows(mysqli_query($connect,"select `id` from `buy` WHERE `id` = '$from_id'"));
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ اطلاعات فرد مورد نظر با موفقیت یافت شد

👤 آیدی عددی فرد = $text

👥 تعداد زیرمجموعه فرد = {$user['member']} عدد

💵 موجودی فرد = {$user['coin']} تومان

📞 شماره فرد = {$user['phone']}

💲 دعوت شده توسط = {$user['inviter']}

💰 جمع پرداختی های فرد = $allbuys عدد

📍 اطلاعات اولین پرداخت فرد :

🏷 شماره پرداخت = {$buy['key']}

💵 مبلغ پرداختی = {$buy['amount']} تومان

⏰ پرداخت شده در ساعت = {$buy['time']}

📍 کانال بازدید خودکار :

💳 آیدی عددی چنل = {$channel['channel']}

👁‍🗨 مقدار بازدید خودکار = {$channel['view']} عدد

`$botname $dateji $timeji`",
'parse_mode' => 'Markdown',
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'unblock' && $tc == 'private') {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✅ فرد با موفقیت لغو مسدود شد",
 ]);
$connect->query("DELETE FROM `block` WHERE `id` = '$text'");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'charge') {	
 	bot('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"✅ فاکتور افزایش موجودی وبسرویس :
	
	📍 نکته ! آیدی عددی $adminapi حتما ربات $webserviceid را استارت کرده باشد",
			'reply_to_message_id'=>$message_id,
			'reply_markup'=>json_encode([
    'inline_keyboard'=>[
	[['text' => "پرداخت فاکتور بمبلغ $text تومان", 'url' =>"https://t.me/CleverSeenApiBot"]],
              ]
              ])
	       ]);	
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'block' && $tc == 'private') {
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"✅ فرد با موفقیت مسدود شد",
	         ]);	
$connect->query("INSERT INTO `block` (`id`) VALUES ('$text')");
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
}
elseif($user['step'] == 'sendadmin') {
$all = explode("\n", $text);	
			bot('sendmessage',[       
			'chat_id'=>$chat_id,
			'text'=>"انتقال موجودی با موفقیت انجام شد ✅",
	         ]);
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$all[0]' LIMIT 1"));			 
$coin = $user['coin'] + $all[1] ;
			bot('sendmessage',[       
			'chat_id'=>$all[0],
			'text'=>"✅ $all[1] تومان موجودی از طرف مدیریت ربات برای شما انتقال داده شد .
💰 موجودی جدید شما : $coin تومان",
	]);	
$connect->query("UPDATE `user` SET `coin` = '$coin' WHERE `id` = '$all[0]' LIMIT 1");
bot('sendmessage', [
			'chat_id'=>"@{$setting['channelenteghalat']}",
            'text' => "
            💰 اهدای پول از طرف #مدیر
$from_id
[$from_id](tg://user?id=$from_id)
مشخصات 👇👇

مبلغ :  $all[1] تومان
 آیدی کاربر : [$all[0]](tg://user?id=$all[0])
میزان موجودی فعلی کاربر : $coin تومان

            ",
			'parse_mode' => 'Markdown',
			]);	
}
elseif ($user['step'] == 'sendtoall') {
$photo = $message->photo[count($message->photo)-1]->file_id;
$caption = $update->message->caption;
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"✔️ پیام شما با موفقیت برای ارسال همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
$connect->query("UPDATE `sendall` SET step = 'send' , `text` = '$text$caption' , `chat` = '$photo' LIMIT 1");			
}
elseif ($user['step'] == 'fortoall') {
         bot('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"✔️ پیام شما با موفقیت به عنوان فوروارد همگانی تنظیم شد",
 ]);
$connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");	
$connect->query("UPDATE `sendall` SET `step` = 'forward' , `text` = '$message_id' , `chat` = '$chat_id' LIMIT 1");		
}
//===========================// answer //===========================
elseif($update->message->text && $update->message->reply_to_message && $from_id == $admin[0]){
	bot('sendmessage',[
        'chat_id'=>$chat_id,
        'text'=>'☑️ پاسخ شما برای فرد ارسال شد'
		]);
	bot('sendmessage',[
        'chat_id'=>$update->message->reply_to_message->forward_from->id,
        'text'=>"👮🏻 پاسخ پشتیبان برای شما : $text",
		]);
}
//===========================// channel //===========================
elseif($channel_post and $user['channel'] == true){
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
  $amountautoview = $user['view'] * $setting['seen'];
  if(mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '{$user['id']}' LIMIT 1"))['coin'] >= $amountautoview){	
  if($channel_post->audio != true){
  $id = bot('ForwardMessage',[
  'chat_id'=>"@$channelorder",   
  'from_chat_id'=>$channel_post_chat_id,
  'message_id'=>$channel_post_message_id,
  ])->result->message_id;
  } else {
  $id = $channel_post_message_id;
  $channelorder = $channel_post_chat_username;
  }  
  $link = "https://t.me/$channelorder/$id";
  $explode = explode('^',$user['speed']);  
  $result = curl("$webapi/?apikey=$apikey&type=view&count={$user['view']}&speed=0&period=0&channel=@$channelorder&id=$id");
  if($result->result == 'ok' ){
  $amountautoview = $user['view'] * $setting['seen'];
  $connect->query("UPDATE `user` SET `coin` = `coin` - $amountautoview WHERE `id` = '{$user['id']}' LIMIT 1");
  $startorder = ($explode[0] == 0)?'فوری':"بعد از $explode[0] دقیقه";
  $speed = ($explode[1] == 0)?'حداکثر سرعت':"هر $explode[1] دقیقه $explode[2] بازدید";
  $order_id = $result1["order"];
  $seenstart = $result1["seenstart"];
  bot('sendmessage',[
	'chat_id'=>$user['id'],
    'text'=>"☑️ سفارش بازدید خودکار با شماره پیگیری {$result->order} ثبت شد .

⚡️ سرعت تکمیل : $startorder و $speed 
💰 هزینه سفارش : $amountautoview تومان
👁‍🗨 تعداد بازدید درخواستی : {$user['view']}
👁 بازدید فعلی : {$result->seenstart}",
            ]);
  $connect->query("INSERT INTO `orderseen` (`key` , `id` , `amount` , `speed` , `view` , `link` , `time`) VALUES ('{$result->order}' ,'{$user['id']}' , '$amountautoview' , '$speed' , '{$user['view']}' , '$link' , '".jdate('j F')." در ساعت ".jdate('H:i:s')."')");			
	bot('sendmessage',[
      'chat_id'=>"@$channelorder",
        'text'=>"☑️ سفارش بازدید خودکار با شماره پیگیری {$result->order} ثبت شد .

⚡️ سرعت تکمیل : $startorder و $speed 
💰 هزینه سفارش : $amountautoview تومان
👁‍🗨 تعداد بازدید درخواستی : {$user['view']}
👁 بازدید فعلی : {$result->seenstart}

  [{$user['id']}](tg://user?id={$user['id']})",
'parse_mode'=>'Markdown',
                ]);
}else
    bot('sendmessage',[
	'chat_id'=>$user['id'],
	'text'=>"❗️ خطا ، پست شما نامعتبر است یا مشکلی در انجام سفارش ایجاد شده است

👈🏻 توجه کنید که امکان ثبت سفارش بازدید خودکار برای پست موسیقی در کانال های خصوصی امکان پذیر نیست 
👮🏻 در صورت بروز هرگونه مشکل و یا انجام نشدن سفارش کافیست با پشتیبانی در تماس باشید .",
            ]);	
}else{
    $title = bot('getchat',['chat_id'=>$channel_post_chat_id])->result->title;
	bot('sendmessage',[
	'chat_id'=>$user['id'],
	'text'=>"❗️ سفارش بازدید خودکار برای کانال $title انجام نشد .

✅ برای انجام سفارش باید حداقل $amountautoview تومان موجودی داشته باشید .
❌ برای حذف کانال /del_".abs($channel_post_chat_id)."",
            ]);	
}
}
//===========================// main //===========================
if ($text == "/start") {
    if ($user['language'] == "fa") {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => $start,
            'reply_to_message_id' => $message_id,
            'reply_markup' => $home
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } elseif ($user['language'] == "en") {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => $starten,
            'reply_to_message_id' => $message_id,
            'reply_markup' => $homeen
        ]);
        $connect->query("UPDATE `user` SET `step` = 'none' WHERE `id` = '$from_id' LIMIT 1");
    } else {
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا زبان موردنظرتان را انتخاب کنید.

Please choose your preferred language.",
            'reply_to_message_id' => $message_id,
            'reply_markup' => $changelan
        ]);  
        if ($user['id'] != true) {
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => $gift
            ]);
            $connect->query("INSERT INTO `user` (id, coin) VALUES ('$from_id', '{$setting['gift']}')");
        }
    }
}

$connect->close();
?>