<!DOCTYPE HTML>
<?php 
//==================================================
include '../config.php';
//==================================================
?>
<html>
	<head>
		<title>آموزش ادمین کردن ربات در کانال</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
			<meta name="description" content="آموزش ادمین کردن ربات در کانال">
      <meta name="keywords" content="آموزش ادمین کردن ربات در کانال">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات <?php echo $botname;?></h1>
						<p>👁‍🗨 افزایش تخصصی بازدید پستهای تلگرامی
❤️ افزایش لایک پستهای تلگرامی
📈 افزایش رای در نظرسنجی ها</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>با پاندا سین به راحتی بازدید لایک و رای پست های تلگرامی خود را افزایش دهید</h2>
										</header>
										<p>1 - 👁‍🗨 افزایش بازدید پستهای تلگرامی<br /><br />
										<img src="images/1.jpg" style="width:220px;height:300px;"><br /><br />
❤️ افزایش لایک و رأی تلگرام<br /><br />
<img src="images/2.jpg" style="width:220px;height:300px;"><br /><br />
🕓 قابلیت تنظیم سرعت و زمان<br /><br />
<img src="images/3.jpg" style="width:220px;height:300px;"><br /><br />
👥 زیرمجموعه گیری و دریافت هدیه<br /><br />
<img src="images/4.jpg" style="width:220px;height:300px;"><br /><br />
بازدید خودکار

📣 بازدید خودکار را فعال کنید و همه کارها را به پاندا سین بسپارید<br /><br />
<img src="images/5.jpg" style="width:220px;height:300px;"><br /><br />
<br />👈🏻 با پاندا سین در کنار شما هستیم تا کمک کنیم به صورت رایگان بازدید پست های تلگرامی شمارا افزایش دهیم .

👈🏻علاوه بر افزایش بازدید پست های شما ما میتوانیم ، لایک و نظر سنجی های پست های شمارا نیز افزایش دهیم .<br /><br />
پاندا سین درخدمت شماست</p>
                                       <ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">ورود به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>