<?php
//نکته مهم: بعد از آماده شدن دیتابیس شما یک بار صفحه اجرا شود
include '../config.php';
error_reporting(0);
//========================== // table creator // ==============================
mysqli_multi_query($connect,"CREATE TABLE `user` (
    `id` BIGINT(32) PRIMARY KEY,
	`step` varchar(50) DEFAULT NULL,
	`member` int DEFAULT '0',
	`coin` int NOT NULL,
    `data` TEXT DEFAULT NULL,
	`inviter` int DEFAULT '0',
	`language` varchar(50) DEFAULT NULL,
	`activeuser` BIGINT(32) DEFAULT NULL,
	`codeveri` BIGINT(32) DEFAULT NULL,
	`fakenumber` BIGINT(32) DEFAULT NULL,
    `phone` BIGINT(32) DEFAULT NULL,
    `com` varchar(11) DEFAULT NULL
            ) default charset = utf8mb4;
     CREATE TABLE `setting` (
	`MerchantID` varchar(155) DEFAULT '0',
	`gift` BIGINT(32) DEFAULT '0',
    `member` BIGINT(32) DEFAULT '0',
    `porsant` BIGINT(32) DEFAULT '0',
	`seen` FLOAT DEFAULT '0',
	`like` BIGINT(32) DEFAULT '0',
	`reaction` BIGINT(32) DEFAULT '0',
	`hadaghalkharid` BIGINT(32) DEFAULT '0',
	`hadaksarkharid` BIGINT(32) DEFAULT '0',
	`channelkharid` varchar(155) DEFAULT '0',
	`channelsabtnumber` varchar(155) DEFAULT '0',
	`channelenteghalat` varchar(155) DEFAULT '0'
    ) default charset = utf8mb4;
	CREATE TABLE `orderseen` (
	`key` varchar(155) PRIMARY KEY,
    `id` BIGINT(32) NOT NULL,
	`amount` int NOT NULL,
	`speed` varchar(90) NOT NULL,
	`view` int NOT NULL,
	`link` TEXT NOT NULL,
	`time` varchar(155) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4;
	CREATE TABLE `orderlike` (
	`key` varchar(155) PRIMARY KEY,
    `id` BIGINT(32) NOT NULL,
	`amount` int NOT NULL,
	`speed` varchar(155) NOT NULL,
	`like` int NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4; 
	CREATE TABLE `orderreaction` (
	`key` varchar(155) PRIMARY KEY,
    `id` BIGINT(32) NOT NULL,
	`amount` int NOT NULL,
    `link` TEXT NOT NULL,
	`time` varchar(90) NOT NULL,
	`stats` boolean DEFAULT false
    ) default charset = utf8mb4; 
	CREATE TABLE `channel` (
	`channel` bigint PRIMARY KEY,
    `id` BIGINT(32) NOT NULL,
	`view` int NOT NULL,
	`speed` varchar(50) NOT NULL
    ) default charset = utf8mb4; 	
    CREATE TABLE `buy` (
	`key` int AUTO_INCREMENT PRIMARY KEY,
    `id` BIGINT(32) NOT NULL,
	`amount` int NOT NULL,
	`time` varchar(155) NOT NULL
    ) default charset = utf8mb4;
	CREATE TABLE `block` (
    `id` BIGINT(32) NOT NULL
    ) default charset = utf8mb4;   	
    CREATE TABLE `daily` (
    `time` varchar(50) DEFAULT '',
    `user` BIGINT(32) DEFAULT '0'
    ) default charset = utf8mb4;
    CREATE TABLE `sendall` (
  	`step` varchar(20) DEFAULT NULL,
	`text` text DEFAULT NULL,
	`chat` varchar(100) DEFAULT NULL,
	`user` BIGINT(32) DEFAULT '0'
    ) default charset = utf8mb4;
    INSERT INTO `sendall` () VALUES ();
    INSERT INTO `daily` () VALUES ();
	INSERT INTO `setting` () VALUES ();");
//========================== // Check connection // ==============================
if ($connect->connect_error) {
   die("خطا در ارتصال به خاطره :" . $connect->connect_error);
}
  echo "دیتابیس متصل و نصب شد ."
?>